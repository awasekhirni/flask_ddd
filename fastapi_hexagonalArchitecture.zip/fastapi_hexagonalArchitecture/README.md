# Hexagonal Architecture with FastAPI

This project demonstrates a clean architecture implementation using FastAPI.

## Features

- Hexagonal architecture pattern
- Swagger/OpenAPI documentation
- JWT authentication
- SQLAlchemy ORM
- Unit and integration tests

## Installation

1. Clone the repository
2. Create and activate a virtual environment
3. Install requirements:
   ```bash
   pip install -r requirements/base.txt
