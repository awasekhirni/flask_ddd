# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/application/user/commands/create_user.py
from uuid import UUID
from dataclasses import dataclass
from domain.user.entities.user import User
from domain.user.value_objects import Email
from domain.user.interfaces.user_repository import UserRepository
from domain.user.interfaces.password_service import PasswordService
from domain.shared.exceptions import DomainValidationError

@dataclass
class CreateUserCommand:
    email: str
    first_name: str
    last_name: str
    password: str

class CreateUserHandler:
    def __init__(
        self,
        user_repository: UserRepository,
        password_service: PasswordService
    ):
        self.user_repository = user_repository
        self.password_service = password_service

    async def handle(self, command: CreateUserCommand) -> UUID:
        # Validate email
        email = Email(command.email)

        # Check if user already exists
        existing_user = await self.user_repository.get_by_email(email)
        if existing_user:
            raise DomainValidationError("User with this email already exists")

        # Hash password
        hashed_password = self.password_service.hash_password(command.password)

        # Create user
        user = User(
            email=email,
            first_name=command.first_name,
            last_name=command.last_name,
            hashed_password=hashed_password
        )

        # Save user
        await self.user_repository.add(user)

        return user.id
