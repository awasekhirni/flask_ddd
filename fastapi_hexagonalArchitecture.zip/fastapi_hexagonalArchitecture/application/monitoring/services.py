# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/application/monitoring/services.py
from typing import Dict
import time
from domain.monitoring.interfaces import HealthCheckRepository

class HealthCheckService:
    def __init__(self, repository: HealthCheckRepository):
        self._repository = repository

    async def check_health(self) -> Dict[str, any]:
        start = time.time()
        db_ok = await self._repository.check_database()
        db_time = (time.time() - start) * 1000

        start = time.time()
        cache_ok = await self._repository.check_cache()
        cache_time = (time.time() - start) * 1000

        return {
            "status": "healthy" if (db_ok and cache_ok) else "unhealthy",
            "services": {
                "database": {
                    "healthy": db_ok,
                    "response_time_ms": db_time
                },
                "cache": {
                    "healthy": cache_ok,
                    "response_time_ms": cache_time
                }
            }
        }

    async def check_readiness(self) -> Dict[str, any]:
        db_ready = await self._repository.check_database()
        cache_ready = await self._repository.check_cache()
        return {
            "ready": db_ready and cache_ready,
            "dependencies": {
                "database": db_ready,
                "cache": cache_ready
            }
        }
