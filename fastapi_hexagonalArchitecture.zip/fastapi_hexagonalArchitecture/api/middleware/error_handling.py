# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/api/middleware/error_handling.py
import logging
from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
from domain.shared.exceptions import (
    DomainValidationError,
    NotFoundError,
    UnauthorizedError,
    ForbiddenError
)

logger = logging.getLogger(__name__)

async def http_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Centralized exception handler for the application."""

    if isinstance(exc, RequestValidationError):
        return handle_validation_error(exc)
    elif isinstance(exc, StarletteHTTPException):
        return handle_http_exception(exc)
    elif isinstance(exc, DomainValidationError):
        return handle_domain_validation_error(exc)
    elif isinstance(exc, NotFoundError):
        return handle_not_found_error(exc)
    elif isinstance(exc, UnauthorizedError):
        return handle_unauthorized_error(exc)
    elif isinstance(exc, ForbiddenError):
        return handle_forbidden_error(exc)

    # Handle unexpected exceptions
    return handle_unexpected_error(request, exc)

def handle_validation_error(exc: RequestValidationError) -> JSONResponse:
    """Handle request validation errors."""
    errors = []
    for error in exc.errors():
        errors.append({
            "field": ".".join(str(loc) for loc in error["loc"]),
            "message": error["msg"],
            "type": error["type"]
        })

    logger.warning("Request validation error", extra={"errors": errors})

    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            "message": "Validation error",
            "code": "validation_error",
            "errors": errors
        }
    )

def handle_http_exception(exc: StarletteHTTPException) -> JSONResponse:
    """Handle HTTP exceptions."""
    logger.warning(
        "HTTP exception",
        extra={
            "status_code": exc.status_code,
            "detail": exc.detail
        }
    )

    return JSONResponse(
        status_code=exc.status_code,
        content={
            "message": exc.detail,
            "code": exc.__class__.__name__.lower()
        }
    )

def handle_domain_validation_error(exc: DomainValidationError) -> JSONResponse:
    """Handle domain validation errors."""
    logger.warning("Domain validation error", extra={"message": str(exc)})

    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content={
            "message": str(exc),
            "code": "domain_validation_error"
        }
    )

def handle_not_found_error(exc: NotFoundError) -> JSONResponse:
    """Handle not found errors."""
    logger.warning("Resource not found", extra={"message": str(exc)})

    return JSONResponse(
        status_code=status.HTTP_404_NOT_FOUND,
        content={
            "message": str(exc),
            "code": "not_found"
        }
    )

def handle_unauthorized_error(exc: UnauthorizedError) -> JSONResponse:
    """Handle unauthorized errors."""
    logger.warning("Unauthorized access attempt", extra={"message": str(exc)})

    return JSONResponse(
        status_code=status.HTTP_401_UNAUTHORIZED,
        content={
            "message": str(exc),
            "code": "unauthorized"
        }
    )

def handle_forbidden_error(exc: ForbiddenError) -> JSONResponse:
    """Handle forbidden errors."""
    logger.warning("Forbidden access attempt", extra={"message": str(exc)})

    return JSONResponse(
        status_code=status.HTTP_403_FORBIDDEN,
        content={
            "message": str(exc),
            "code": "forbidden"
        }
    )

def handle_unexpected_error(request: Request, exc: Exception) -> JSONResponse:
    """Handle unexpected exceptions."""
    logger.error(
        "Unexpected error occurred",
        exc_info=True,
        extra={
            "path": request.url.path,
            "method": request.method
        }
    )

    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "message": "Internal server error",
            "code": "internal_server_error"
        }
    )
