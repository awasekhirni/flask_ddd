# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/api/dependencies.py
from fastapi import Depends
from infrastructure.database.session import get_db
from infrastructure.monitoring.repositories import DatabaseHealthCheckRepository
from application.monitoring.services import HealthCheckService

def get_health_check_service(db = Depends(get_db)) -> HealthCheckService:
    """Dependency that provides configured HealthCheckService"""
    repository = DatabaseHealthCheckRepository(db)
    return HealthCheckService(repository)
