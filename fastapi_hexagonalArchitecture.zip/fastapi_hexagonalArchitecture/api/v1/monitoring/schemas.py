# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/api/v1/monitoring/schemas.py
from pydantic import BaseModel, ConfigDict
from typing import Dict
from datetime import datetime

class ServiceStatus(BaseModel):
    healthy: bool
    response_time_ms: float

    # Modern Pydantic v2 config
    model_config = ConfigDict(from_attributes=True)

class HealthResponse(BaseModel):
    status: str
    services: Dict[str, ServiceStatus]
    version: str = "1.0.0"
    timestamp: datetime

    model_config = ConfigDict(from_attributes=True)

class ReadinessResponse(BaseModel):
    ready: bool
    dependencies: Dict[str, bool]

    model_config = ConfigDict(from_attributes=True)
