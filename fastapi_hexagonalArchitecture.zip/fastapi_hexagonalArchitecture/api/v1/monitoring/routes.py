# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/api/v1/monitoring/routes.py
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from typing import Dict
from application.monitoring.services import HealthCheckService

router = APIRouter(tags=["monitoring"])

class ServiceStatus(BaseModel):
    healthy: bool
    response_time_ms: float

class HealthResponse(BaseModel):
    status: str  # "healthy" or "unhealthy"
    services: Dict[str, ServiceStatus]

class ReadinessResponse(BaseModel):
    ready: bool
    dependencies: Dict[str, bool]

@router.get("/health", response_model=HealthResponse)
async def health_check(
    health_service: HealthCheckService = Depends()
):
    return await health_service.check_health()

@router.get("/ready", response_model=ReadinessResponse)
async def readiness_check(
    health_service: HealthCheckService = Depends()
):
    return await health_service.check_readiness()
