# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/api/v1/auth/schemas.py
from pydantic import BaseModel, EmailStr, Field

class TokenResponse(BaseModel):
    access_token: str
    token_type: str

class UserRegisterRequest(BaseModel):
    email: EmailStr
    first_name: str = Field(..., min_length=1, max_length=100)
    last_name: str = Field(..., min_length=1, max_length=100)
    password: str = Field(..., min_length=8, max_length=100)

class UserRegisterResponse(BaseModel):
    id: str
    email: EmailStr
