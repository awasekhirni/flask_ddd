# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/api/v1/user/schemas.py
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_serializer
from typing import Optional
from datetime import datetime
from domain.user.value_objects import UserStatus
from uuid import UUID

class UserCreateRequest(BaseModel):
    email: EmailStr
    first_name: str = Field(
        ...,
        min_length=1,
        max_length=100,
        examples=["John"],
        description="User's first name"
    )
    last_name: str = Field(
        ...,
        min_length=1,
        max_length=100,
        examples=["Doe"],
        description="User's last name"
    )
    password: str = Field(
        ...,
        min_length=8,
        max_length=100,
        examples=["Str0ngP@ss"],
        description="At least 8 characters with mix of letters, numbers and symbols"
    )

class UserResponse(BaseModel):
    id: UUID
    email: EmailStr
    first_name: str
    last_name: str
    status: UserStatus
    created_at: datetime
    updated_at: Optional[datetime] = None

    # Pydantic v2 configuration
    model_config = ConfigDict(
        from_attributes=True,  # Enables ORM mode (formerly orm_mode)
        json_schema_extra={
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "email": "user@example.com",
                "first_name": "John",
                "last_name": "Doe",
                "status": "active",
                "created_at": "2023-01-01T00:00:00Z",
                "updated_at": "2023-01-02T00:00:00Z"
            }
        },
        protected_namespaces=()  # Removes pydantic namespace warnings
    )

    @field_serializer('id')
    def serialize_id(self, id: UUID, _info):
        return str(id)

    @field_serializer('created_at', 'updated_at')
    def serialize_dates(self, dt: datetime | None, _info):
        return dt.isoformat() if dt else None
