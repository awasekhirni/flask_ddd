# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/api/v1/user/routes.py
from fastapi import APIRouter, Depends, status, HTTPException
from fastapi.security import OAuth2PasswordBearer
from typing import List
from uuid import UUID
from api.v1.user.schemas import UserCreateRequest, UserResponse
from application.user.commands.create_user import CreateUserCommand, CreateUserHandler
from infrastructure.database.session import get_db
from infrastructure.security.password import PasswordService
from infrastructure.database.repositories.user_repository import SQLAlchemyUserRepository
from sqlalchemy.orm import Session

router = APIRouter()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

@router.post("/", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def create_user(
    user_data: UserCreateRequest,
    db: Session = Depends(get_db)
):
    handler = CreateUserHandler(
        user_repository=SQLAlchemyUserRepository(db),
        password_service=PasswordService()
    )

    try:
        user_id = await handler.handle(CreateUserCommand(**user_data.dict()))
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

    # Return the created user
    user = await SQLAlchemyUserRepository(db).get_by_id(user_id)
    return user

@router.get("/", response_model=List[UserResponse])
async def list_users(db: Session = Depends(get_db)):
    repo = SQLAlchemyUserRepository(db)
    users = await repo.list_all()
    return users

@router.get("/{user_id}", response_model=UserResponse)
async def get_user(user_id: UUID, db: Session = Depends(get_db)):
    repo = SQLAlchemyUserRepository(db)
    user = await repo.get_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    return user
