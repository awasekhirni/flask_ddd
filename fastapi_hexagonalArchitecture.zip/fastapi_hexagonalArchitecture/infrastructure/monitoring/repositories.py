# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/infrastructure/monitoring/repositories.py
from sqlalchemy import text
import logging
from domain.monitoring.interfaces import HealthCheckRepository

logger = logging.getLogger(__name__)

class DatabaseHealthCheckRepository(HealthCheckRepository):
    def __init__(self, db):
        self.db = db

    async def check_database(self) -> bool:
        try:
            await self.db.execute(text("SELECT 1"))
            return True
        except Exception as e:
            logger.error(f"Database health check failed: {str(e)}")
            return False

    async def check_cache(self) -> bool:
        # Implement actual cache check
        return True  # Placeholder
