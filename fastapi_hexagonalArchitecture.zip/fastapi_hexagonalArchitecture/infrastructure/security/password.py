# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/infrastructure/security/password.py
from passlib.context import CryptContext
from domain.user.interfaces.password_service import PasswordService

# Configure password hashing
pwd_context = CryptContext(
    schemes=["bcrypt"],
    deprecated="auto",
    bcrypt__rounds=12  # Adjust based on your security requirements
)

class PasswordServiceImpl(PasswordService):
    """Concrete implementation of PasswordService using bcrypt"""

    def hash_password(self, password: str) -> str:
        """Hash a password using bcrypt"""
        return pwd_context.hash(password)

    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """Verify a password against its bcrypt hash"""
        return pwd_context.verify(plain_password, hashed_password)

# Create an alias for easier importing
PasswordService = PasswordServiceImpl
