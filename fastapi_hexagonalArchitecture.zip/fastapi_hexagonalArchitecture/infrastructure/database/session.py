# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/infrastructure/database/session.py
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from infrastructure.config.database import get_db_settings

db_settings = get_db_settings()

engine = create_engine(
    str(db_settings.DATABASE_URL),
    pool_size=db_settings.POOL_SIZE,
    max_overflow=db_settings.MAX_OVERFLOW,
    echo=db_settings.ECHO
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
