# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/infrastructure/database/mappers.py
from domain.user.entities.user import User
from infrastructure.database.models.user import UserModel

class UserMapper:
    @staticmethod
    def to_entity(model: UserModel) -> User:
        return User(
            id=model.id,
            email=model.email,
            first_name=model.first_name,
            last_name=model.last_name,
            hashed_password=model.hashed_password,
            status=model.status,
            created_at=model.created_at,
            updated_at=model.updated_at
        )

    @staticmethod
    def to_model(entity: User) -> UserModel:
        return UserModel(
            id=entity.id,
            email=entity.email.value,
            first_name=entity.first_name,
            last_name=entity.last_name,
            hashed_password=entity.hashed_password,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )
