# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

#hexagonal_architecture/infrastructure/database/base.py
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()
