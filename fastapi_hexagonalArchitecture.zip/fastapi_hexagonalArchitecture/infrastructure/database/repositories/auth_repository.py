# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/infrastructure/database/repositories/auth_repository.py
from uuid import UUID
from sqlalchemy.orm import Session
from domain.auth.interfaces.auth_repository import AuthRepository
from domain.user.entities.user import User
from infrastructure.database.models.session import SessionModel

class SQLAlchemyAuthRepository(AuthRepository):
    def __init__(self, session: Session):
        self.session = session

    async def create_user_session(self, user: User) -> None:
        session = SessionModel(user_id=user.id)
        self.session.add(session)
        self.session.commit()

    async def get_user_from_session(self, session_id: UUID) -> User:
        session = self.session.query(SessionModel).filter_by(id=session_id).first()
        if session:
            return session.user
        return None

    async def invalidate_session(self, session_id: UUID) -> None:
        session = self.session.query(SessionModel).filter_by(id=session_id).first()
        if session:
            self.session.delete(session)
            self.session.commit()
