# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/infrastructure/database/repositories/user_repository.py
from typing import Optional, List
from uuid import UUID
from sqlalchemy.orm import Session
from domain.user.entities.user import User
from domain.user.interfaces.user_repository import UserRepository
from domain.user.value_objects import Email
from infrastructure.database.models.user import UserModel
from infrastructure.database.mappers.user_mapper import UserMapper

class SQLAlchemyUserRepository(UserRepository):
    def __init__(self, session: Session):
        self.session = session

    async def get_by_id(self, user_id: UUID) -> Optional[User]:
        model = self.session.query(UserModel).filter_by(id=user_id).first()
        return UserMapper.to_entity(model) if model else None

    async def get_by_email(self, email: Email) -> Optional[User]:
        model = self.session.query(UserModel).filter_by(email=email.value).first()
        return UserMapper.to_entity(model) if model else None

    async def add(self, user: User) -> None:
        model = UserMapper.to_model(user)
        self.session.add(model)

    async def update(self, user: User) -> None:
        model = UserMapper.to_model(user)
        self.session.merge(model)

    async def list_all(self) -> List[User]:
        models = self.session.query(UserModel).all()
        return [UserMapper.to_entity(model) for model in models]
