# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/infrastructure/database/models/user.py
from sqlalchemy import Column, String, DateTime, Enum, UUID
from sqlalchemy.sql import func
from infrastructure.database.base import Base
from domain.user.value_objects import UserStatus

class UserModel(Base):
    __tablename__ = "users"

    id = Column(UUID, primary_key=True)
    email = Column(String(255), unique=True, nullable=False)
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    hashed_password = Column(String(255), nullable=False)
    status = Column(Enum(UserStatus), nullable=False, default=UserStatus.ACTIVE)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


    # Session relationship
    # sessions = relationship("SessionModel", back_populates="user")
