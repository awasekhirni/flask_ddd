# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/infrastructure/database/session.py
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from infrastructure.config.database import get_db_settings

db_settings = get_db_settings()

# Convert URL to string explicitly
database_url = str(db_settings.DATABASE_URL)

engine = create_engine(
    database_url,
    pool_size=db_settings.DB_POOL_SIZE,
    max_overflow=db_settings.DB_MAX_OVERFLOW,
    pool_pre_ping=True
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
