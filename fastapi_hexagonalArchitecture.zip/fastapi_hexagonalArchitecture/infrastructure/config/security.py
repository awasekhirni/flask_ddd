# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/infrastructure/config/security.py
from pydantic import BaseSettings

class SecuritySettings(BaseSettings):
    SECRET_KEY: str = "your-secret-key-here"  # Change this to a strong secret
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30

    class Config:
        env_file = ".env"

def get_security_settings() -> SecuritySettings:
    return SecuritySettings()
