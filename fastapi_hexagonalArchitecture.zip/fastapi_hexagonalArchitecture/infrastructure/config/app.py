# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/infrastructure/config/app.py
from pydantic_settings import BaseSettings
from pydantic import  PostgresDsn
from typing import List


class AppSettings(BaseSettings):
    PROJECT_NAME: str = "Hexagonal FastAPI"
    DEBUG: bool = False
    VERSION: str = "1.0.0"
    DOCS_URL: str = "/docs"
    OPENAPI_URL: str = "/openapi.json"
    ALLOWED_HOSTS: List[str] = ["*"]

    class Config:
        env_prefix = "APP_"  # Add prefix for app-specific settings
        env_file = ".env"
        extra = "ignore"

def get_app_settings() -> AppSettings:
    return AppSettings()
