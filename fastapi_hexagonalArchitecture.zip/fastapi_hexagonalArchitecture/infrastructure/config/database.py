# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/infrastructure/config/database.py
from pydantic_settings import BaseSettings
from pydantic import  PostgresDsn


class DatabaseSettings(BaseSettings):
    DATABASE_URL: PostgresDsn = "postgresql://user:password@localhost:5432/dbname"
    POOL_SIZE: int = 5
    MAX_OVERFLOW: int = 10
    ECHO: bool = False

    class Config:
        env_prefix = "DB_"  # Add prefix for database-specific settings
        env_file = ".env"
        extra = "ignore"

def get_db_settings() -> DatabaseSettings:
    return DatabaseSettings()
