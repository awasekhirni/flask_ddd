#Copyright (C) 2025 β ORI Inc.
#Written by Awase Khirni Syed 2025
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from infrastructure.config.app import get_app_settings
from api.middleware.logging import LoggingMiddleware
from api.middleware.error_handling import http_exception_handler
from fastapi.exceptions import RequestValidationError
import uvicorn
from typing import Dict, Any

# Initialize logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan management"""
    logger.info("Starting application...")
    # Initialize resources here
    yield
    logger.info("Shutting down application...")
    # Clean up resources here

def custom_openapi() -> Dict[str, Any]:
    """Generate customized OpenAPI schema"""
    if app.openapi_schema:
        return app.openapi_schema

    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        description="""
        ## Hexagonal Architecture API Documentation

        This API follows hexagonal architecture principles with:
        - Clear separation of concerns
        - Domain-driven design
        - Infrastructure independence
        """,
        routes=app.routes,
        servers=[{"url": "http://localhost:8787", "description": "Local development server"}],
    )

    # Enhanced OpenAPI customization
    openapi_schema["info"].update({
        "contact": {
            "name": "API Support",
            "email": "support@example.com"
        },
        "license": {
            "name": "MIT",
            "url": "https://opensource.org/licenses/MIT"
        }
    })

    # Security scheme for JWT authentication
    openapi_schema["components"]["securitySchemes"] = {
        "BearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT",
            "description": "Enter JWT token in format: **Bearer <token>**"
        }
    }

    # Add global security requirement
    openapi_schema["security"] = [{"BearerAuth": []}]

    # Add tags metadata for better organization
    openapi_schema["tags"] = [
        {
            "name": "auth",
            "description": "Authentication and authorization operations"
        },
        {
            "name": "user",
            "description": "User management operations"
        },
        # {
        #     "name": "monitoring",
        #     "description": "Health checks and metrics"
        # }
    ]

    app.openapi_schema = openapi_schema
    return app.openapi_schema

def create_application() -> FastAPI:
    """Application factory"""
    settings = get_app_settings()

    app = FastAPI(
        title=settings.PROJECT_NAME,
        debug=settings.DEBUG,
        version=settings.VERSION,
        docs_url=settings.DOCS_URL,
        openapi_url=settings.OPENAPI_URL,
        lifespan=lifespan,
        swagger_ui_parameters={
            "syntaxHighlight.theme": "obsidian",
            "tryItOutEnabled": True,
            "displayRequestDuration": True,
            "filter": True,
            "persistAuthorization": True,  # Preserves auth tokens
            "docExpansion": "list",  # Collapses operations by default
        },
        redoc_url="/redoc" if settings.DOCS_URL else None
    )

    # Middleware configuration
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.ALLOWED_HOSTS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.add_middleware(LoggingMiddleware)

    # Exception handlers
    app.add_exception_handler(RequestValidationError, http_exception_handler)

    # Custom OpenAPI schema
    app.openapi = custom_openapi

    return app

app = create_application()

# Import and include routers with enhanced metadata
from api.v1.auth.routes import router as auth_router
from api.v1.user.routes import router as user_router
# from api.v1.monitoring.routes import router as monitoring_router

app.include_router(
    auth_router,
    prefix="/api/v1/auth",
    tags=["auth"],
    responses={
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden"}
    }
)

app.include_router(
    user_router,
    prefix="/api/v1/user",
    tags=["user"],
    responses={
        404: {"description": "User not found"},
        400: {"description": "Invalid request"}
    }
)

# app.include_router(
#     monitoring_router,
#     prefix="/api/v1/monitoring",
#     tags=["monitoring"],
#     responses={
#         503: {"description": "Service unavailable"}
#     }
# )

if __name__ == "__main__":
    uvicorn.run(
        "app:app",
        host="0.0.0.0",
        port=8787,
        reload=True,
        log_level="info",
        proxy_headers=True,
        timeout_keep_alive=60
    )
