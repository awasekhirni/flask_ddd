# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/domain/auth/interfaces/token_service.py

from abc import ABC, abstractmethod

class TokenService(ABC):
    @abstractmethod
    def create_access_token(self, data: dict) -> str:
        raise NotImplementedError

    @abstractmethod
    def verify_access_token(self, token: str) -> dict:
        raise NotImplementedError
