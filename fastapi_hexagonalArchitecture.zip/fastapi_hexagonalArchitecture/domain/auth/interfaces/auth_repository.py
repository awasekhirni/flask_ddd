# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/domain/auth/interfaces/auth_repository.py
from abc import ABC, abstractmethod
from uuid import UUID
from domain.user.entities.user import User

class AuthRepository(ABC):
    @abstractmethod
    async def create_user_session(self, user: User) -> None:
        raise NotImplementedError

    @abstractmethod
    async def get_user_from_session(self, session_id: UUID) -> User:
        raise NotImplementedError

    @abstractmethod
    async def invalidate_session(self, session_id: UUID) -> None:
        raise NotImplementedError
