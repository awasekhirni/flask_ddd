# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/domain/shared/exceptions.py
class DomainException(Exception):
    """Base class for all domain exceptions."""
    pass

class DomainValidationError(DomainException):
    """Raised when domain validation fails."""
    pass

class NotFoundError(DomainException):
    """Raised when a resource is not found."""
    pass

class UnauthorizedError(DomainException):
    """Raised when a user is not authorized."""
    pass

class ForbiddenError(DomainException):
    """Raised when a user is forbidden from accessing a resource."""
    pass

class ConflictError(DomainException):
    """Raised when a resource conflict occurs."""
    pass

class BusinessRuleViolation(DomainException):
    """Raised when a business rule is violated."""
    pass

class DomainValidationError(Exception):
    """Raised when domain validation fails"""
    pass
