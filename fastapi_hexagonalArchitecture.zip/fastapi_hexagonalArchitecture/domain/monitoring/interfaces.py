# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/domain/monitoring/interfaces.py
from abc import ABC, abstractmethod

class HealthCheckRepository(ABC):
    @abstractmethod
    async def check_database(self) -> bool:
        raise NotImplementedError

    @abstractmethod
    async def check_cache(self) -> bool:
        raise NotImplementedError
