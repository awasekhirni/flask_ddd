# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/domain/user/entities/user.py
from datetime import datetime
from uuid import UUID, uuid4
from domain.user.value_objects import Email, UserStatus

class User:
    def __init__(
        self,
        email: Email,
        first_name: str,
        last_name: str,
        hashed_password: str,
        id: UUID = None,
        status: UserStatus = None,
        created_at: datetime = None,
        updated_at: datetime = None
    ):
        self.id = id or uuid4()
        self.email = email
        self.first_name = first_name
        self.last_name = last_name
        self.hashed_password = hashed_password
        self.status = status or UserStatus.ACTIVE
        self.created_at = created_at or datetime.utcnow()
        self.updated_at = updated_at or datetime.utcnow()

    def __eq__(self, other):
        if not isinstance(other, User):
            return False
        return self.id == other.id

    def update_details(self, first_name: str, last_name: str):
        self.first_name = first_name
        self.last_name = last_name
        self.updated_at = datetime.utcnow()

    def change_password(self, new_hashed_password: str):
        self.hashed_password = new_hashed_password
        self.updated_at = datetime.utcnow()

    def deactivate(self):
        self.status = UserStatus.INACTIVE
        self.updated_at = datetime.utcnow()
