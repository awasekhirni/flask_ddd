# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/domain/user/interfaces/password_service.py
from abc import ABC, abstractmethod

class PasswordService(ABC):
    """Interface for password hashing and verification"""

    @abstractmethod
    def hash_password(self, password: str) -> str:
        """Hash a password for storage"""
        raise NotImplementedError

    @abstractmethod
    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """Verify a password against its hash"""
        raise NotImplementedError
