# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# hexagonal_architecture/domain/user/value_objects/email.py
import re
from dataclasses import dataclass
from domain.shared.exceptions import DomainValidationError

@dataclass(frozen=True)
class Email:
    value: str

    def __post_init__(self):
        if not self.is_valid(self.value):
            raise DomainValidationError("Invalid email address")

    @classmethod
    def is_valid(cls, email: str) -> bool:
        """Validate email format using regex"""
        pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
        return re.match(pattern, email) is not None

    def __str__(self):
        return self.value
