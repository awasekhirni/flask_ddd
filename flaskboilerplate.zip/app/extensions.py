#project/app/extensions.py for shared service registration 

from flask_sqlalchemy import SQLAlchemy 
from flask_jwt_extended import JWTManager 

#database SQLALchemy and JWTManager
db=SQLAlchemy()
jwt=JWTManager()


#initialize extensions 

def init_extensions(app):
    db.init_app(app)
    jwt.init_app(app)