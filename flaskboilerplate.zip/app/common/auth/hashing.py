#project/app/common/auth/hashing.py

from werkzeug.security import generate_password_hash

def hash_password(password: str) -> str:
    return generate_password_hash(password)
