
#project/app/modules/users/domain/domain_exceptions.py 


class UserDomainException(Exception):
    """Base class for user domain exceptions."""
    pass


class UserAlreadyExistsException(UserDomainException):
    def __init__(self, email: str):
        self.email = email
        super().__init__(f"User with email '{email}' already exists.")


class UserNotFoundException(UserDomainException):
    def __init__(self, user_id: str = None, email: str = None):
        if user_id:
            message = f"User with ID '{user_id}' not found."
        elif email:
            message = f"User with email '{email}' not found."
        else:
            message = "User not found."
        super().__init__(message)


class InvalidUserCredentialsException(UserDomainException):
    def __init__(self):
        super().__init__("Invalid email or password.")


class UserUnauthorizedException(UserDomainException):
    def __init__(self):
        super().__init__("User is not authorized to perform this action.")

