#project/app/apps/modules/users/domain/entities/user_entity.py
#Users module domain entity 
#Awase Khirni Syed Copyright 2025 β ORI Inc


class User:
    def __init__(self, id: int, email: str, password_hash: str):
        self.id = id
        self.email = email
        self.password_hash = password_hash


