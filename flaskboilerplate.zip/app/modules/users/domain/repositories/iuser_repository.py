#project/app/apps/modules/users/domain/repositories/iuser_repository.py
#Awase Khirni Syed Copyright 2025 β ORI Inc

from abc import ABC, abstractmethod
from typing import Optional
from app.modules.users.domain.entities.user_entity import User

class IUserRepository(ABC):
    @abstractmethod
    def create(self, user: User) -> User:
        """Persist a new user."""
        pass

    @abstractmethod
    def get_by_id(self, user_id: str) -> Optional[User]:
        """Retrieve a user by their ID."""
        pass

    @abstractmethod
    def get_by_email(self, email: str) -> Optional[User]:
        """Retrieve a user by their email."""
        pass

    @abstractmethod
    def update(self, user: User) -> User:
        """Update an existing user."""
        pass

    @abstractmethod
    def delete(self, user_id: str) -> None:
        """Delete a user by their ID."""
        pass
