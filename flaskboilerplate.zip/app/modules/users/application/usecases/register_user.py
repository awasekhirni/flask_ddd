#project/app/apps/modules/users/application/usecases/register_user.py

from app.extensions import db 
from app.config import Config
from app.modules.users.infrastructure.repository_impl.sqlalchemy_user_repository import SQLAlchemyUserRepository


class UserAlreadyExistsException(Exception):
    pass

class RegisterUserUseCase():

    def __init__(self, user_repository: SQLAlchemyUserRepository):
        self.user_repository = user_repository

    def execute(self, user):
        existing_user = self.user_repository.get_by_email(user.email)
        if existing_user:
            raise UserAlreadyExistsException(f"User with email {user.email} already exists.")

        new_user = self.user_repository.create(user)
        return new_user