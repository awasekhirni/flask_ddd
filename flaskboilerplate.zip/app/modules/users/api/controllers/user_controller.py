#project/app/apps/modules/api/controllers/user_controller.py
##Awase Khirni Syed Copyright 2025 β ORI Inc.   
from flask import Blueprint, request, jsonify
from marshmallow import ValidationError
from flask_restx import Namespace, Resource, fields
from app.modules.users.api.dtos.user_dto import UserDTOSchema
from app.modules.users.api.mappers.user_mapper import dto_to_entity
from app.modules.users.application.usecases.register_user import RegisterUserUseCase
from app.modules.users.user_repository_factory import get_user_repository
from app.modules.users.domain.domain_exceptions import (
    UserAlreadyExistsException,
    UserNotFoundException,
    InvalidUserCredentialsException,
    UserUnauthorizedException
)
user_ns = Namespace("users", description="User operations")

# Swagger model (basic example)
user_input = user_ns.model("UserInput", {
    "email": fields.String(required=True, example="user@example.com"),
    "password": fields.String(required=True, example="password123"),
})

user_output = user_ns.model("UserOutput", {
    "id": fields.String(example="1"),
    "email": fields.String(example="user@example.com")
})


@user_ns.route("/register")
class RegisterUserController(Resource):
    @user_ns.expect(user_input)
    @user_ns.response(201, "User registered successfully.", model=user_output)
    @user_ns.response(400, "Validation error")
    @user_ns.response(409, "User already exists")
    @user_ns.response(500, "Internal server error")
    def post(self):
        schema = UserDTOSchema()

        try:
            user_dto = schema.load(request.json)
            user_entity = dto_to_entity(user_dto)

            repo = get_user_repository()
            use_case = RegisterUserUseCase(repo)

            new_user = use_case.execute(user_entity)

            return {
                "id": new_user.id,
                "email": new_user.email
            }, 201

        except ValidationError as ve:
            return {"errors": ve.messages}, 400
        except UserAlreadyExistsException as e:
            return {"error": str(e)}, 409
        except Exception:
            return {"error": "Internal server error"}, 500
