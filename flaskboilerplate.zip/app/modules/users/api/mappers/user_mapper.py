#project/app/modules/users/api/mappers/user_mapper.py 

from app.modules.users.domain.entities.user_entity import User
from app.modules.users.api.dtos.user_dto import UserDTO
from app.common.auth.hashing import hash_password  # Example utility

def dto_to_entity(dto: UserDTO) -> User:
    return User(id=None, email=dto.email, password_hash=hash_password(dto.password))

def entity_to_dto(entity: User) -> UserDTO:
    return UserDTO(email=entity.email, password="****")  # Never return real password
