#project/app/modules/users/api/dtos/user_dto.py

from dataclasses import dataclass
from marshmallow import Schema, fields, post_load

@dataclass
class UserDTO:
    email: str
    password: str


class UserDTOSchema(Schema):
    email = fields.Email(required=True)
    password = fields.String(required=True, load_only=True)

    @post_load
    def make_user_dto(self, data, **kwargs):
        return UserDTO(**data)
