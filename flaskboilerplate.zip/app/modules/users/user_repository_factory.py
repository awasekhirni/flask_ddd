#/project/app/apps/modules/users/user_repository_factory.py 


from app.extensions import db 
from app.modules.users.infrastructure.repository_impl.sqlalchemy_user_repository import SQLAlchemyUserRepository

def get_user_repository():
    return SQLAlchemyUserRepository(db.session)