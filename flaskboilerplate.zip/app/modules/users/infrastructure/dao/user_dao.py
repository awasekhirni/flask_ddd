#project/app/apps/modules/users/infrastructure/dao/user_dao.py
#Awase Khirni Syed Copyright 2025 β ORI Inc

from app.extensions import db
from app.modules.users.domain.entities.user_entity import User

class UserDAO(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)

    def to_entity(self):
        return User(self.id, self.email, self.password_hash)