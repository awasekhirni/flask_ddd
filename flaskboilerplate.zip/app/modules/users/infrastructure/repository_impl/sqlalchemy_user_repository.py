#project/app/apps/modules/users/infrastructure/repository_impl/sqlalchemy_user_repository.py 
##Awase Khirni Syed Copyright 2025 β ORI Inc
from app.modules.users.domain.repositories.iuser_repository import IUserRepository
from app.modules.users.infrastructure.dao.user_dao import UserDAO
from app.modules.users.domain.entities.user_entity import User

class SQLAlchemyUserRepository(IUserRepository):
    def __init__(self, session):
        self.session = session

    def get_by_id(self, user_id: int) -> User:
        dao = self.session.query(UserDAO).get(user_id)
        return dao.to_entity() if dao else None

    def get_by_email(self, email: str) -> User:
        dao = self.session.query(UserDAO).filter_by(email=email).first()
        return dao.to_entity() if dao else None

    def create(self, user: User) -> User:
        dao = UserDAO(email=user.email, password_hash=user.password_hash)
        self.session.add(dao)
        self.session.commit()
        return dao.to_entity()