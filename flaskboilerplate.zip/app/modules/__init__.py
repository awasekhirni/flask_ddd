#project/app/modules/__init__.py
#Dynamic Module Registration 
#Awase Khirni Syed Copyright 2025 β ORI Inc
import pkgutil
import importlib
from flask import Blueprint

def register_all_modules(app, base_package='app.modules', api_version='v1'):
    """
    Auto-discover and register all Flask blueprints in `app.modules`, including versioned URL prefixes.
    Each module should contain an `api.controllers` with at least one Blueprint.
    Optionally, each `controllers.py` can define `__api_version__` to override the default version.
    """
    package = importlib.import_module(base_package)

    for finder, name, ispkg in pkgutil.iter_modules(package.__path__, base_package + "."):
        try:
            controllers_module_path = f"{name}.api.controllers"
            controllers = importlib.import_module(controllers_module_path)

            # Use module-specific API version if defined
            module_version = getattr(controllers, "__api_version__", api_version)

            # Register all Blueprint instances in the module
            for attr_name in dir(controllers):
                attr = getattr(controllers, attr_name)
                if isinstance(attr, Blueprint):
                    module_name = name.split('.')[-1]
                    url_prefix = f"/api/{module_version}/{module_name}"
                    app.register_blueprint(attr, url_prefix=url_prefix)
                    print(f"Registered {attr.name} at {url_prefix}")

        except ModuleNotFoundError:
            continue  # Gracefully skip modules without controllers
