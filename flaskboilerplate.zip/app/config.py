#project/app/config.py
#Awase Khirni Syed Copyright 2025 β ORI Inc.
import os
from dotenv import load_dotenv
load_dotenv()

class Config:
    DB_TYPE = os.getenv("DB_TYPE", "sqlite")
    SQLALCHEMY_DATABASE_URI = os.getenv("SQLALCHEMY_DATABASE_URI", "sqlite:///app.db")
    JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "supersecret")


