#project/app/__init__.py
#central app factory 
#Awase Khirni Syed Copyright 2025 β ORI Inc

from flask import Flask
from flask_restx import Api
from app.config import Config
from app.extensions import init_extensions
from app.modules.users.api.controllers.user_controller import user_ns

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Initialize extensions
    init_extensions(app)

    # Setup Swagger API
    api = Api(app, title="My Flask API", version="1.0", description="Clean Architecture API", doc="/api/docs")

    # Register namespaces (modular Swagger endpoints)
    api.add_namespace(user_ns, path="/api/users")

    # Redirect root URL to /api/docs
    @app.route('/')
    def index():
        return redirect('/api/docs')

    return app