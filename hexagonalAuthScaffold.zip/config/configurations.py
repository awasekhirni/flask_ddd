# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

import os
from functools import lru_cache
from dotenv import load_dotenv
from pydantic import BaseModel, SecretStr, Field
from pathlib import Path
from typing import Optional

# Load environment variables from .env file
load_dotenv(dotenv_path=Path('.') / '.env')

class DatabaseConfig(BaseModel):
    user: str = Field(default=..., env="APP_POSTGRES_USER")
    password: SecretStr = Field(default=..., env="APP_POSTGRES_PASSWORD")
    db_name: str = Field(default=..., env="APP_POSTGRES_DB")
    host: str = Field(default="localhost", env="APP_POSTGRES_HOST")
    port: str = Field(default="5432", env="APP_POSTGRES_PORT")
    pool_size: int = Field(default=5, env="APP_DB_POOL_SIZE")
    max_overflow: int = Field(default=10, env="APP_DB_MAX_OVERFLOW")
    pool_recycle: int = Field(default=3600, env="APP_DB_POOL_RECYCLE")
    driver: str = Field(default="asyncpg")

    @property
    def url(self) -> str:
        return (
            f"postgresql://{self.user}:{self.password.get_secret_value()}"
            f"@{self.host}:{self.port}/{self.db_name}"
        )

    @property
    def async_url(self) -> str:
        return (
            f"postgresql+{self.driver}://{self.user}:{self.password.get_secret_value()}"
            f"@{self.host}:{self.port}/{self.db_name}"
        )

    @property
    def safe_url(self) -> str:
        return f"postgresql+{self.driver}://{self.user}:****@{self.host}:{self.port}/{self.db_name}"

class JWTConfig(BaseModel):
    secret_key: SecretStr = Field(default=..., env="APP_SECRET_KEY")
    algorithm: str = Field(default="HS256", env="APP_ALGORITHM")
    access_token_expire_minutes: int = Field(default=30, env="APP_ACCESS_TOKEN_EXPIRE_MINUTES")

class LoggingConfig(BaseModel):
    level: str = Field(default="INFO", env="APP_LOG_LEVEL")
    dir: str = Field(default="logs", env="APP_LOG_DIR")
    max_bytes: int = Field(default=5_000_000, env="APP_LOG_MAX_BYTES")
    backup_count: int = Field(default=3, env="APP_LOG_BACKUP_COUNT")
    enable_console: bool = Field(default=True, env="APP_LOG_ENABLE_CONSOLE")
    enable_file: bool = Field(default=False, env="APP_LOG_ENABLE_FILE")

class AppConfig(BaseModel):
    debug: bool = Field(default=False, env="APP_DEBUG")
    env: str = Field(default="production", env="APP_FLASK_ENV")
    name: str = Field(default="Hexagonal Auth API", env="APP_APP_NAME")
    version: str = Field(default="1.0.0", env="APP_APP_VERSION")

class Config(BaseModel):
    app: AppConfig
    database: DatabaseConfig
    jwt: JWTConfig
    logging: LoggingConfig

@lru_cache()
def get_config() -> Config:
    """Get cached application configuration"""
    return Config(
        app=AppConfig(
            debug=os.getenv("APP_DEBUG", "false").lower() == "true",
            env=os.getenv("APP_FLASK_ENV", "production"),
            name=os.getenv("APP_APP_NAME", "Hexagonal Auth API"),
            version=os.getenv("APP_APP_VERSION", "1.0.0"),
        ),
        database=DatabaseConfig(
            user=os.getenv("APP_POSTGRES_USER"),
            password=SecretStr(os.getenv("APP_POSTGRES_PASSWORD")),
            db_name=os.getenv("APP_POSTGRES_DB"),
            host=os.getenv("APP_POSTGRES_HOST", "localhost"),
            port=os.getenv("APP_POSTGRES_PORT", "5432"),
            pool_size=int(os.getenv("APP_DB_POOL_SIZE", "5")),
            max_overflow=int(os.getenv("APP_DB_MAX_OVERFLOW", "10")),
            pool_recycle=int(os.getenv("APP_DB_POOL_RECYCLE", "3600")),
            driver="asyncpg"
        ),
        jwt=JWTConfig(
            secret_key=SecretStr(os.getenv("APP_SECRET_KEY")),
            algorithm=os.getenv("APP_ALGORITHM", "HS256"),
            access_token_expire_minutes=int(os.getenv("APP_ACCESS_TOKEN_EXPIRE_MINUTES", "30")),
        ),
        logging=LoggingConfig(
            level=os.getenv("APP_LOG_LEVEL", "INFO"),
            dir=os.getenv("APP_LOG_DIR", "logs"),
            max_bytes=int(os.getenv("APP_LOG_MAX_BYTES", "5000000")),
            backup_count=int(os.getenv("APP_LOG_BACKUP_COUNT", "3")),
            enable_console=os.getenv("APP_LOG_ENABLE_CONSOLE", "true").lower() == "true",
            enable_file=os.getenv("APP_LOG_ENABLE_FILE", "false").lower() == "true",
        ),
    )

# Global configuration instance
config = get_config()

# Global configuration instance
config = get_config()

#usage
# from config.configurations import config

# # Database URL
# db_url = config.database.async_url

# # JWT Configuration
# secret_key = config.jwt.secret_key.get_secret_value()
