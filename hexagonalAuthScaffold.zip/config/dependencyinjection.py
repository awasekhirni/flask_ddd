# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

from typing import AsyncGenerator
from sqlalchemy.ext.asyncio import AsyncSession
from infrastructure.database.db import async_session
from application.services.users.async_user_service_impl import AsyncUserServiceImpl
from infrastructure.repositories.users.async_user_repository_impl import AsyncUserRepository

class Container:
    def __init__(self):
        self._dependencies = {}

    def register(self, key, provider):
        self._dependencies[key] = provider

    async def resolve(self, key):
        provider = self._dependencies[key]
        return await provider()

container = Container()

async def get_user_service() -> AsyncGenerator[AsyncUserServiceImpl, None]:
    """Dependency generator for user service"""
    async with async_session() as session:
        repo = AsyncUserRepository(session)
        service = AsyncUserServiceImpl(repo)
        try:
            yield service
        finally:
            await session.close()

def setup_dependencies():
    container.register('user_service', get_user_service)
