from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any
from datetime import datetime
from shared.async_base_repository import IAsyncBaseRepository
from domain.users.users_entity import Users as User

class IAsyncUserRepository(IAsyncBaseRepository[User], ABC):
    """Asynchronous interface for User repository operations extending base repository"""

    @abstractmethod
    async def authenticate_user(self, username: str, password: str) -> Optional[User]:
        """Authenticate a user asynchronously by username and password"""
        pass

    @abstractmethod
    async def assign_role_to_user(self, user_id: int, role: str) -> Optional[User]:
        """Assign a role to a user asynchronously"""
        pass

    @abstractmethod
    async def remove_role_from_user(self, user_id: int, role: str) -> Optional[User]:
        """Remove a role from a user asynchronously"""
        pass

    @abstractmethod
    async def get_users_by_role(self, role: str, *, skip: int = 0, limit: int = 100) -> List[User]:
        """Retrieve users by their role asynchronously with pagination"""
        pass

    @abstractmethod
    async def get_user_by_email(self, email: str) -> Optional[User]:
        """Retrieve a user by email address asynchronously"""
        pass

    @abstractmethod
    async def get_user_by_username(self, username: str) -> Optional[User]:
        """Retrieve a user by username asynchronously"""
        pass

    @abstractmethod
    async def get_users_by_status(self, status: str, *, skip: int = 0, limit: int = 100) -> List[User]:
        """Get users by status asynchronously with pagination"""
        pass

    @abstractmethod
    async def update_user_profile(self, user_id: int, updated_data: Dict[str, Any]) -> Optional[User]:
        """Update specific profile fields asynchronously"""
        pass

    @abstractmethod
    async def reset_user_password(self, user_id: int, new_password: str) -> bool:
        """Reset password asynchronously, returns success status"""
        pass

    @abstractmethod
    async def change_user_status(self, user_id: int, status: str) -> Optional[User]:
        """Change user status asynchronously"""
        pass

    @abstractmethod
    async def assign_permissions_to_user(self, user_id: int, permissions: List[str]) -> Optional[User]:
        """Assign permissions asynchronously"""
        pass

    @abstractmethod
    async def remove_permissions_from_user(self, user_id: int, permissions: List[str]) -> Optional[User]:
        """Remove permissions asynchronously"""
        pass

    @abstractmethod
    async def get_user_last_login(self, user_id: int) -> Optional[datetime]:
        """Get last login timestamp asynchronously"""
        pass

    @abstractmethod
    async def get_users_by_registration_date_range(
        self,
        start_date: datetime,
        end_date: datetime,
        *,
        skip: int = 0,
        limit: int = 100
    ) -> List[User]:
        """Get users registered between dates asynchronously with pagination"""
        pass

    @abstractmethod
    async def search_users(self, query: str, *, skip: int = 0, limit: int = 100) -> List[User]:
        """Search users by query string asynchronously with pagination"""
        pass

    @abstractmethod
    async def get_user_with_relations(self, user_id: int, relation_names: List[str]) -> Optional[User]:
        """Get user with related entities loaded asynchronously"""
        pass

    @abstractmethod
    async def soft_delete_user(self, user_id: int) -> bool:
        """Soft delete user (mark as deleted) asynchronously"""
        pass
