from abc import ABC, abstractmethod
from typing import List, Optional, Dict
from datetime import datetime
from shared.async_base_service import IAsyncBaseService
from domain.users.users_entity import Users as User

class IAsyncUserService(IAsyncBaseService[User], ABC):
    """Asynchronous user service interface extending base service"""

    @abstractmethod
    async def authenticate_user(self, email: str, password: str) -> Optional[User]:
        """Asynchronously authenticate a user by email and password"""
        pass

    @abstractmethod
    async def get_user_by_email(self, email: str) -> Optional[User]:
        """Asynchronously retrieve a user by email"""
        pass

    @abstractmethod
    async def get_user_by_username(self, username: str) -> Optional[User]:
        """Asynchronously retrieve a user by username"""
        pass

    @abstractmethod
    async def get_first_10_users(self) -> List[User]:
        """Asynchronously retrieve the first 10 users"""
        pass

    @abstractmethod
    async def assign_role(self, user_id: int, role: str) -> Optional[User]:
        """Asynchronously assign a role to a user"""
        pass

    @abstractmethod
    async def remove_role(self, user_id: int, role: str) -> Optional[User]:
        """Asynchronously remove a role from a user"""
        pass

    @abstractmethod
    async def assign_permissions(self, user_id: int, permissions: List[str]) -> Optional[User]:
        """Asynchronously assign permissions to a user"""
        pass

    @abstractmethod
    async def remove_permissions(self, user_id: int, permissions: List[str]) -> Optional[User]:
        """Asynchronously remove permissions from a user"""
        pass

    @abstractmethod
    async def reset_password(self, user_id: int, new_password: str) -> Optional[User]:
        """Asynchronously reset a user's password"""
        pass

    @abstractmethod
    async def change_status(self, user_id: int, status: str) -> Optional[User]:
        """Asynchronously change a user's account status"""
        pass

    @abstractmethod
    async def update_profile(self, user_id: int, profile_data: Dict) -> Optional[User]:
        """Asynchronously update profile-related fields"""
        pass

    @abstractmethod
    async def get_users_by_registration_period(self, start_date: str, end_date: str) -> List[User]:
        """Asynchronously retrieve users registered within a date range"""
        pass

    @abstractmethod
    async def get_user_last_login(self, user_id: int) -> Optional[str]:
        """Asynchronously retrieve the user's last login timestamp"""
        pass
