from enum import Enum
from uuid import uuid4
from datetime import datetime

from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, Enum as SqlEnum
from sqlalchemy.dialects.postgresql import UUID
from werkzeug.security import generate_password_hash, check_password_hash
from infrastructure.database.db import Base


class AvailabilityEnum(str, Enum):
    FULL_TIME = "Full-Time"
    PART_TIME = "Part-Time"
    UNAVAILABLE = "Unavailable"


class Users(Base):
    __tablename__ = 'users'

    user_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4, nullable=False)
    email = Column(String, nullable=False, unique=True)
    password_hash = Column(String, nullable=False)
    full_name = Column(String)
    last_name = Column(String)
    profile_summary = Column(Text)
    location = Column(String)
    language_preference = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    region_id = Column(Integer)
    political_affiliation_id = Column(Integer)
    political_affiliation_visibility = Column(Boolean, default=False)
    profile_visibility = Column(String)
    is_profile_approved = Column(Boolean, default=False)
    encryption_key_id = Column(UUID(as_uuid=True))
    industry_id = Column(Integer)
    is_verified_influencer = Column(Boolean, default=False)
    availability = Column(SqlEnum(AvailabilityEnum, name="availability_enum"), nullable=True)

    def __repr__(self):
        return f"<Users(user_id={self.user_id})>"

    def __str__(self):
        return f"User({self.user_id}): {self.full_name or self.email}"

    def __eq__(self, other):
        return isinstance(other, Users) and self.user_id == other.user_id

    def __hash__(self):
        return hash(self.user_id)

    def __lt__(self, other):
        if isinstance(other, Users):
            return self.created_at < other.created_at
        return NotImplemented

    def set_password(self, raw_password: str):
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password: str) -> bool:
        return check_password_hash(self.password_hash, raw_password)

    def to_dict(self, include_sensitive: bool = False, exclude_fields: list = None) -> dict:
        data = {
            "user_id": str(self.user_id),
            "email": self.email,
            "full_name": self.full_name,
            "last_name": self.last_name,
            "profile_summary": self.profile_summary,
            "location": self.location,
            "language_preference": self.language_preference,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "region_id": self.region_id,
            "political_affiliation_id": self.political_affiliation_id,
            "political_affiliation_visibility": self.political_affiliation_visibility,
            "profile_visibility": self.profile_visibility,
            "is_profile_approved": self.is_profile_approved,
            "encryption_key_id": str(self.encryption_key_id) if self.encryption_key_id else None,
            "industry_id": self.industry_id,
            "is_verified_influencer": self.is_verified_influencer,
            "availability": self.availability.value if self.availability else None,
        }

        if include_sensitive:
            data["password_hash"] = self.password_hash

        if exclude_fields:
            for field in exclude_fields:
                data.pop(field, None)

        return data

    @classmethod
    def from_dict(cls, data: dict):
        allowed_fields = {
            "user_id", "email", "full_name", "last_name", "profile_summary", "location",
            "language_preference", "created_at", "region_id", "political_affiliation_id",
            "political_affiliation_visibility", "profile_visibility", "is_profile_approved",
            "encryption_key_id", "industry_id", "is_verified_influencer"
        }

        user = cls(**{k: v for k, v in data.items() if k in allowed_fields})

        if "availability" in data:
            try:
                user.availability = AvailabilityEnum(data["availability"])
            except ValueError:
                raise ValueError(f"Invalid availability: {data['availability']}")

        if "password" in data:
            user.set_password(data["password"])

        return user
