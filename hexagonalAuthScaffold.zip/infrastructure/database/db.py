# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

import logging
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, AsyncEngine
from sqlalchemy.orm import sessionmaker, declarative_base
from contextlib import asynccontextmanager
from typing import AsyncGenerator, Optional
from sqlalchemy import text
from config.configurations import config
import asyncio

logger = logging.getLogger(__name__)

Base = declarative_base()

class AsyncDatabase:
    def __init__(self):
        self.engine: Optional[AsyncEngine] = None
        self.async_session_factory: Optional[sessionmaker] = None
        self._initialized = False

    async def init_db(self):
        """Initialize async database connection with proper connection pooling"""
        if self._initialized:
            return

        try:
            self.engine = create_async_engine(
                config.database.async_url,
                pool_size=config.database.pool_size,
                max_overflow=config.database.max_overflow,
                pool_recycle=config.database.pool_recycle,
                pool_pre_ping=True,
                pool_timeout=30,  # Wait up to 30 seconds for a connection from pool
                connect_args={
                    "command_timeout": 10,  # Timeout for individual commands
                    "server_settings": {
                        "application_name": config.app.name,
                        "statement_timeout": "15000"  # 15 seconds statement timeout
                    }
                },
                echo=config.logging.level == "DEBUG"  # Enable SQL query logging in debug mode
            )

            # Verify connection with retry logic
            max_retries = 3
            for attempt in range(max_retries):
                try:
                    async with self.engine.begin() as conn:
                        await conn.execute(text("SELECT 1"))
                    break
                except Exception as e:
                    if attempt == max_retries - 1:
                        raise
                    await asyncio.sleep(1 * (attempt + 1))
                    logger.warning(f"Database connection attempt {attempt + 1} failed, retrying...")
                    continue

            self.async_session_factory = sessionmaker(
                bind=self.engine,
                class_=AsyncSession,
                expire_on_commit=False,
                autoflush=False
            )

            self._initialized = True
            logger.info("Async database initialized successfully")

        except Exception as e:
            logger.critical("Async database initialization failed", exc_info=True)
            raise

    @asynccontextmanager
    async def get_session(self) -> AsyncGenerator[AsyncSession, None]:
        """Async context manager for database sessions with proper error handling"""
        if not self._initialized:
            raise RuntimeError("Database not initialized. Call init_db() first.")

        session = self.async_session_factory()
        try:
            yield session
            await session.commit()
        except Exception as e:
            await session.rollback()
            logger.error("Database operation failed", exc_info=True)
            raise
        finally:
            await session.close()

    async def close(self):
        """Close all database connections"""
        if self.engine:
            await self.engine.dispose()
            self._initialized = False
            logger.info("Async database connections closed")

# Singleton async database instance
async_db = AsyncDatabase()
