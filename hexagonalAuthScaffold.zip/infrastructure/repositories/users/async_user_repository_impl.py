# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

from typing import List, Optional, Dict, Any
from datetime import datetime
from sqlalchemy import select, update, delete, and_, or_, func, between
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import joinedload
from domain.users.users_entity import Users as User  # Correct import path
from domain.users.async_user_repository_interface import IAsyncUserRepository
from infrastructure.database.db import async_db


class UserRepositoryImpl(IAsyncUserRepository):
    """Complete SQLAlchemy implementation of IAsyncUserRepository using async_db singleton"""

    def __init__(self):
        pass  # No need for session in constructor since we'll use async_db's context manager

    async def _execute_with_session(self, operation):
        """Helper method to execute operations within a session context"""
        async with async_db.get_session() as session:
            return await operation(session)

    # Basic CRUD operations
    async def get_all_users(self, *, skip: int = 0, limit: int = 100) -> List[User]:
        async def op(session):
            result = await session.execute(
                select(User)
                .offset(skip)
                .limit(limit)
            )
            return result.scalars().all()
        return await self._execute_with_session(op)

    async def get_user(self, user_id: int) -> Optional[User]:
        async def op(session):
            result = await session.execute(
                select(User)
                .where(User.id == user_id)
            )
            return result.scalar_one_or_none()
        return await self._execute_with_session(op)

    async def create_user(self, user_data: Dict[str, Any]) -> User:
        async def op(session):
            user = User(**user_data)
            session.add(user)
            await session.flush()
            await session.refresh(user)
            await session.commit()
            return user
        return await self._execute_with_session(op)

    async def update_user(self, user_id: int, user_data: Dict[str, Any]) -> Optional[User]:
        async def op(session):
            result = await session.execute(
                update(User)
                .where(User.id == user_id)
                .values(**user_data)
                .returning(User)
            )
            await session.commit()
            return result.scalar_one_or_none()
        return await self._execute_with_session(op)

    async def delete_user(self, user_id: int) -> bool:
        async def op(session):
            result = await session.execute(
                delete(User)
                .where(User.id == user_id)
            )
            await session.commit()
            return result.rowcount > 0
        return await self._execute_with_session(op)

    # Authentication and user lookup
    async def authenticate_user(self, username: str, password: str) -> Optional[User]:
        async def op(session):
            result = await session.execute(
                select(User)
                .where(
                    and_(
                        User.username == username,
                        User.hashed_password == password  # Should compare with hashed password
                    )
                )
            )
            return result.scalar_one_or_none()
        return await self._execute_with_session(op)

    async def get_user_by_email(self, email: str) -> Optional[User]:
        async def op(session):
            result = await session.execute(
                select(User)
                .where(User.email == email)
            )
            return result.scalar_one_or_none()
        return await self._execute_with_session(op)

    async def get_user_by_username(self, username: str) -> Optional[User]:
        async def op(session):
            result = await session.execute(
                select(User)
                .where(User.username == username)
            )
            return result.scalar_one_or_none()
        return await self._execute_with_session(op)

    # Role and permission management
    async def assign_role_to_user(self, user_id: int, role: str) -> Optional[User]:
        async def op(session):
            user = await self.get_user(user_id)
            if user:
                if not user.roles:
                    user.roles = []
                if role not in user.roles:
                    user.roles.append(role)
                    await session.commit()
            return user
        return await self._execute_with_session(op)

    async def remove_role_from_user(self, user_id: int, role: str) -> Optional[User]:
        async def op(session):
            user = await self.get_user(user_id)
            if user and user.roles and role in user.roles:
                user.roles.remove(role)
                await session.commit()
            return user
        return await self._execute_with_session(op)

    async def assign_permissions_to_user(self, user_id: int, permissions: List[str]) -> Optional[User]:
        async def op(session):
            user = await self.get_user(user_id)
            if user:
                if not user.permissions:
                    user.permissions = []
                for permission in permissions:
                    if permission not in user.permissions:
                        user.permissions.append(permission)
                await session.commit()
            return user
        return await self._execute_with_session(op)

    async def remove_permissions_from_user(self, user_id: int, permissions: List[str]) -> Optional[User]:
        async def op(session):
            user = await self.get_user(user_id)
            if user and user.permissions:
                for permission in permissions:
                    if permission in user.permissions:
                        user.permissions.remove(permission)
                await session.commit()
            return user
        return await self._execute_with_session(op)

    # Bulk operations
    async def bulk_create_users(self, users_data: List[Dict[str, Any]]) -> List[User]:
        async def op(session):
            users = [User(**data) for data in users_data]
            session.add_all(users)
            await session.flush()
            await session.commit()
            return users
        return await self._execute_with_session(op)

    async def bulk_update_users(self, updates: List[Dict[str, Any]]) -> List[User]:
        async def op(session):
            updated_users = []
            for update_data in updates:
                user_id = update_data.pop('id')
                result = await session.execute(
                    update(User)
                    .where(User.id == user_id)
                    .values(**update_data)
                    .returning(User)
                )
                updated_users.append(result.scalar_one())
            await session.commit()
            return updated_users
        return await self._execute_with_session(op)

    # Filtering and searching
    async def get_users_by_role(self, role: str, *, skip: int = 0, limit: int = 100) -> List[User]:
        async def op(session):
            result = await session.execute(
                select(User)
                .where(User.roles.contains([role]))
                .offset(skip)
                .limit(limit)
            )
            return result.scalars().all()
        return await self._execute_with_session(op)

    async def get_users_by_status(self, status: str, *, skip: int = 0, limit: int = 100) -> List[User]:
        async def op(session):
            result = await session.execute(
                select(User)
                .where(User.status == status)
                .offset(skip)
                .limit(limit)
            )
            return result.scalars().all()
        return await self._execute_with_session(op)

    async def filter_users(self, *conditions: Any, skip: int = 0, limit: int = 100) -> List[User]:
        async def op(session):
            result = await session.execute(
                select(User)
                .where(and_(*conditions))
                .offset(skip)
                .limit(limit)
            )
            return result.scalars().all()
        return await self._execute_with_session(op)

    async def search_users(self, query: str, *, skip: int = 0, limit: int = 100) -> List[User]:
        async def op(session):
            search_pattern = f"%{query}%"
            result = await session.execute(
                select(User)
                .where(
                    or_(
                        User.username.ilike(search_pattern),
                        User.email.ilike(search_pattern),
                        User.full_name.ilike(search_pattern)
                    )
                )
                .offset(skip)
                .limit(limit)
            )
            return result.scalars().all()
        return await self._execute_with_session(op)

    # Utility methods
    async def count_users(self, **filters: Any) -> int:
        async def op(session):
            query = select(func.count()).select_from(User)
            if filters:
                conditions = [getattr(User, key) == value for key, value in filters.items()]
                query = query.where(and_(*conditions))
            result = await session.execute(query)
            return result.scalar_one()
        return await self._execute_with_session(op)

    async def user_exists(self, **filters: Any) -> bool:
        async def op(session):
            query = select(User)
            if filters:
                conditions = [getattr(User, key) == value for key, value in filters.items()]
                query = query.where(and_(*conditions))
            result = await session.execute(query.limit(1))
            return result.scalar_one_or_none() is not None
        return await self._execute_with_session(op)

    # Specialized queries
    async def get_user_last_login(self, user_id: int) -> Optional[datetime]:
        async def op(session):
            result = await session.execute(
                select(User.last_login)
                .where(User.id == user_id)
            )
            return result.scalar_one_or_none()
        return await self._execute_with_session(op)

    async def get_users_by_registration_date_range(
        self,
        start_date: datetime,
        end_date: datetime,
        *,
        skip: int = 0,
        limit: int = 100
    ) -> List[User]:
        async def op(session):
            result = await session.execute(
                select(User)
                .where(between(User.created_at, start_date, end_date))
                .offset(skip)
                .limit(limit)
            )
            return result.scalars().all()
        return await self._execute_with_session(op)

    async def get_user_with_relations(self, user_id: int, relation_names: List[str]) -> Optional[User]:
        async def op(session):
            query = select(User).where(User.id == user_id)
            for relation in relation_names:
                query = query.options(joinedload(getattr(User, relation)))
            result = await session.execute(query)
            return result.scalar_one_or_none()
        return await self._execute_with_session(op)

    async def soft_delete_user(self, user_id: int) -> bool:
        async def op(session):
            result = await session.execute(
                update(User)
                .where(User.id == user_id)
                .values(is_deleted=True, deleted_at=func.now())
            )
            await session.commit()
            return result.rowcount > 0
        return await self._execute_with_session(op)

    # Additional methods
    async def get_first_n_users(self, n: int = 10) -> List[User]:
        async def op(session):
            result = await session.execute(
                select(User)
                .limit(n)
            )
            return result.scalars().all()
        return await self._execute_with_session(op)

    async def get_users_paginated(self, page: int, per_page: int) -> List[User]:
        async def op(session):
            skip = (page - 1) * per_page
            result = await session.execute(
                select(User)
                .offset(skip)
                .limit(per_page)
            )
            return result.scalars().all()
        return await self._execute_with_session(op)

    async def get_sorted_users(self, sort_field: str, ascending: bool = True, *, skip: int = 0, limit: int = 100) -> List[User]:
        async def op(session):
            field = getattr(User, sort_field)
            order_by = field.asc() if ascending else field.desc()
            result = await session.execute(
                select(User)
                .order_by(order_by)
                .offset(skip)
                .limit(limit)
            )
            return result.scalars().all()
        return await self._execute_with_session(op)

    async def get_user_by_field(self, field_name: str, value: Any) -> Optional[User]:
        async def op(session):
            result = await session.execute(
                select(User)
                .where(getattr(User, field_name) == value)
            )
            return result.scalar_one_or_none()
        return await self._execute_with_session(op)

    async def filter_users_by_fields(self, fields: Dict[str, Any], *, skip: int = 0, limit: int = 100) -> List[User]:
        async def op(session):
            conditions = [getattr(User, key) == value for key, value in fields.items()]
            result = await session.execute(
                select(User)
                .where(and_(*conditions))
                .offset(skip)
                .limit(limit)
            )
            return result.scalars().all()
        return await self._execute_with_session(op)

    async def update_user_profile(self, user_id: int, updated_data: Dict[str, Any]) -> Optional[User]:
        async def op(session):
            profile_fields = {k: v for k, v in updated_data.items() if k in [
                'bio', 'avatar_url', 'location', 'website'  # Example profile fields
            ]}
            if not profile_fields:
                return None

            result = await session.execute(
                update(User)
                .where(User.id == user_id)
                .values(**profile_fields)
                .returning(User)
            )
            await session.commit()
            return result.scalar_one_or_none()
        return await self._execute_with_session(op)

    async def reset_user_password(self, user_id: int, new_password: str) -> bool:
        async def op(session):
            result = await session.execute(
                update(User)
                .where(User.id == user_id)
                .values(hashed_password=new_password)  # Should be hashed
            )
            await session.commit()
            return result.rowcount > 0
        return await self._execute_with_session(op)

    async def change_user_status(self, user_id: int, status: str) -> Optional[User]:
        async def op(session):
            result = await session.execute(
                update(User)
                .where(User.id == user_id)
                .values(status=status)
                .returning(User)
            )
            await session.commit()
            return result.scalar_one_or_none()
        return await self._execute_with_session(op)
