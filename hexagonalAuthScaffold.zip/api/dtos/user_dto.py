# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

from typing import List, Optional
from datetime import datetime
from pydantic import BaseModel, EmailStr, field_validator
from enum import Enum

class UserStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"

class UserBaseDTO(BaseModel):
    username: str
    email: EmailStr

class UserCreateDTO(UserBaseDTO):
    password: str
    roles: List[str] = []
    status: UserStatus = UserStatus.ACTIVE

    @field_validator('password')
    def validate_password(cls, v):
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        return v

class UserUpdateDTO(BaseModel):
    username: Optional[str] = None
    email: Optional[EmailStr] = None
    password: Optional[str] = None
    roles: Optional[List[str]] = None
    status: Optional[UserStatus] = None

class UserResponseDTO(UserBaseDTO):
    id: int
    roles: List[str]
    status: UserStatus
    created_at: datetime
    last_login: Optional[datetime] = None

    class Config:
        from_attributes = True

class UserLoginDTO(BaseModel):
    username: str
    password: str

class UserRoleUpdateDTO(BaseModel):
    role: str

class UserBulkCreateDTO(BaseModel):
    users: List[UserCreateDTO]

class UserBulkUpdateDTO(BaseModel):
    users: List[dict]  # Contains id and fields to update
