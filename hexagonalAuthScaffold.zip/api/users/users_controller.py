# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

from flask import request
from flask_restx import Namespace, Resource, fields
from typing import List, Dict, Optional
from datetime import datetime
from application.services.users.async_user_service_impl import UserServiceImpl
from domain.users.users_entity import Users as User
from shared.exceptions import NotFoundException, AuthenticationFailedException

# Initialize namespace
api = Namespace('users', description='User operations')

# Request/Response models
user_model = api.model('User', {
    'id': fields.Integer(readonly=True, description='User identifier'),
    'username': fields.String(required=True, description='Username'),
    'email': fields.String(required=True, description='Email address'),
    'full_name': fields.String(description='Full name'),
    'status': fields.String(description='Account status'),
    'roles': fields.List(fields.String, description='User roles'),
    'created_at': fields.DateTime(description='Creation date'),
    'last_login': fields.DateTime(description='Last login date')
})

create_user_model = api.model('CreateUser', {
    'username': fields.String(required=True),
    'email': fields.String(required=True),
    'password': fields.String(required=True),
    'full_name': fields.String(),
    'status': fields.String(default='active')
})

update_user_model = api.model('UpdateUser', {
    'username': fields.String(),
    'email': fields.String(),
    'full_name': fields.String(),
    'status': fields.String()
})

login_model = api.model('Login', {
    'email': fields.String(required=True),
    'password': fields.String(required=True)
})

role_model = api.model('Role', {
    'role': fields.String(required=True)
})

permissions_model = api.model('Permissions', {
    'permissions': fields.List(fields.String, required=True)
})

password_reset_model = api.model('PasswordReset', {
    'new_password': fields.String(required=True)
})

status_model = api.model('Status', {
    'status': fields.String(required=True)
})

profile_model = api.model('Profile', {
    'bio': fields.String(),
    'avatar_url': fields.String(),
    'location': fields.String(),
    'website': fields.String()
})

date_range_model = api.model('DateRange', {
    'start_date': fields.String(required=True, description='Start date (YYYY-MM-DD)'),
    'end_date': fields.String(required=True, description='End date (YYYY-MM-DD)')
})

@api.route('/')
class UserList(Resource):
    @api.doc('list_users')
    @api.marshal_list_with(user_model)
    @api.param('page', 'Page number', type=int)
    @api.param('per_page', 'Items per page', type=int)
    async def get(self):
        """List all users"""
        page = request.args.get('page', default=1, type=int)
        per_page = request.args.get('per_page', default=10, type=int)
        return await user_service.get_paginated(page, per_page)

    @api.doc('create_user')
    @api.expect(create_user_model)
    @api.marshal_with(user_model, code=201)
    async def post(self):
        """Create a new user"""
        data = request.json
        user = User(**data)
        return await user_service.create(user), 201

@api.route('/<int:user_id>')
@api.response(404, 'User not found')
@api.param('user_id', 'The user identifier')
class UserResource(Resource):
    @api.doc('get_user')
    @api.marshal_with(user_model)
    async def get(self, user_id):
        """Fetch a user given its identifier"""
        user = await user_service.get_by_id(user_id)
        if not user:
            api.abort(404, "User not found")
        return user

    @api.doc('update_user')
    @api.expect(update_user_model)
    @api.marshal_with(user_model)
    async def put(self, user_id):
        """Update a user"""
        data = request.json
        user = User(**data)
        updated_user = await user_service.update(user_id, user)
        if not updated_user:
            api.abort(404, "User not found")
        return updated_user

    @api.doc('delete_user')
    @api.response(204, 'User deleted')
    async def delete(self, user_id):
        """Delete a user"""
        success = await user_service.delete(user_id)
        if not success:
            api.abort(404, "User not found")
        return '', 204

@api.route('/login')
class UserLogin(Resource):
    @api.doc('user_login')
    @api.expect(login_model)
    @api.marshal_with(user_model)
    async def post(self):
        """Authenticate a user"""
        data = request.json
        try:
            user = await user_service.authenticate_user(data['email'], data['password'])
            return user
        except AuthenticationFailedException:
            api.abort(401, "Invalid credentials")

@api.route('/email/<string:email>')
@api.response(404, 'User not found')
@api.param('email', 'The user email')
class UserByEmail(Resource):
    @api.doc('get_user_by_email')
    @api.marshal_with(user_model)
    async def get(self, email):
        """Fetch a user by email"""
        user = await user_service.get_user_by_email(email)
        if not user:
            api.abort(404, "User not found")
        return user

@api.route('/username/<string:username>')
@api.response(404, 'User not found')
@api.param('username', 'The username')
class UserByUsername(Resource):
    @api.doc('get_user_by_username')
    @api.marshal_with(user_model)
    async def get(self, username):
        """Fetch a user by username"""
        user = await user_service.get_user_by_username(username)
        if not user:
            api.abort(404, "User not found")
        return user

@api.route('/<int:user_id>/roles')
@api.response(404, 'User not found')
class UserRoles(Resource):
    @api.doc('assign_role')
    @api.expect(role_model)
    @api.marshal_with(user_model)
    async def post(self, user_id):
        """Assign a role to user"""
        data = request.json
        user = await user_service.assign_role(user_id, data['role'])
        if not user:
            api.abort(404, "User not found")
        return user

    @api.doc('remove_role')
    @api.expect(role_model)
    @api.marshal_with(user_model)
    async def delete(self, user_id):
        """Remove a role from user"""
        data = request.json
        user = await user_service.remove_role(user_id, data['role'])
        if not user:
            api.abort(404, "User not found")
        return user

@api.route('/<int:user_id>/permissions')
@api.response(404, 'User not found')
class UserPermissions(Resource):
    @api.doc('assign_permissions')
    @api.expect(permissions_model)
    @api.marshal_with(user_model)
    async def post(self, user_id):
        """Assign permissions to user"""
        data = request.json
        user = await user_service.assign_permissions(user_id, data['permissions'])
        if not user:
            api.abort(404, "User not found")
        return user

    @api.doc('remove_permissions')
    @api.expect(permissions_model)
    @api.marshal_with(user_model)
    async def delete(self, user_id):
        """Remove permissions from user"""
        data = request.json
        user = await user_service.remove_permissions(user_id, data['permissions'])
        if not user:
            api.abort(404, "User not found")
        return user

@api.route('/<int:user_id>/password')
@api.response(404, 'User not found')
class UserPassword(Resource):
    @api.doc('reset_password')
    @api.expect(password_reset_model)
    @api.response(204, 'Password updated')
    async def put(self, user_id):
        """Reset user password"""
        data = request.json
        success = await user_service.reset_password(user_id, data['new_password'])
        if not success:
            api.abort(404, "User not found")
        return '', 204

@api.route('/<int:user_id>/status')
@api.response(404, 'User not found')
class UserStatus(Resource):
    @api.doc('change_status')
    @api.expect(status_model)
    @api.marshal_with(user_model)
    async def put(self, user_id):
        """Change user status"""
        data = request.json
        user = await user_service.change_status(user_id, data['status'])
        if not user:
            api.abort(404, "User not found")
        return user

@api.route('/<int:user_id>/profile')
@api.response(404, 'User not found')
class UserProfile(Resource):
    @api.doc('update_profile')
    @api.expect(profile_model)
    @api.marshal_with(user_model)
    async def put(self, user_id):
        """Update user profile"""
        data = request.json
        user = await user_service.update_profile(user_id, data)
        if not user:
            api.abort(404, "User not found")
        return user

@api.route('/registered-between')
class UsersByRegistrationPeriod(Resource):
    @api.doc('get_users_by_registration_period')
    @api.expect(date_range_model)
    @api.marshal_list_with(user_model)
    async def post(self):
        """Get users registered between dates"""
        data = request.json
        try:
            return await user_service.get_users_by_registration_period(
                data['start_date'],
                data['end_date']
            )
        except ValueError as e:
            api.abort(400, str(e))

@api.route('/<int:user_id>/last-login')
@api.response(404, 'User not found or never logged in')
class UserLastLogin(Resource):
    @api.doc('get_user_last_login')
    async def get(self, user_id):
        """Get user's last login timestamp"""
        last_login = await user_service.get_user_last_login(user_id)
        if not last_login:
            api.abort(404, "User not found or never logged in")
        return {'last_login': last_login.isoformat()}
