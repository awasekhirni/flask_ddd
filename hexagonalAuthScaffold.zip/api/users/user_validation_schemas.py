# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

from pydantic import BaseModel, EmailStr, Field, model_validator, field_validator
from typing import Optional
from datetime import datetime
from enum import Enum
import re

class UserStatus(str, Enum):
    """User account status enumeration"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"

class UserRole(str, Enum):
    """User roles enumeration"""
    ADMIN = "admin"
    MANAGER = "manager"
    USER = "user"

class UserBaseSchema(BaseModel):
    """Base schema for user models"""
    email: EmailStr = Field(..., example="user@example.com")
    full_name: Optional[str] = Field(
        None,
        min_length=2,
        max_length=100,
        example="John Doe"
    )
    role: UserRole = Field(default=UserRole.USER)
    status: UserStatus = Field(default=UserStatus.ACTIVE)

    class Config:
        use_enum_values = True
        json_encoders = {datetime: lambda v: v.isoformat()}

class UserCreateSchema(UserBaseSchema):
    """Schema for user creation"""
    password: str = Field(
        ...,
        min_length=8,
        max_length=64,
        description="Must be at least 8 characters with mix of letters, numbers and symbols"
    )
    password_confirm: str = Field(..., exclude=True)

    @field_validator('password')
    @classmethod
    def validate_password_strength(cls, v: str) -> str:
        """Validate password meets complexity requirements"""
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        if not re.search(r"[A-Z]", v):
            raise ValueError("Password must contain at least one uppercase letter")
        if not re.search(r"[a-z]", v):
            raise ValueError("Password must contain at least one lowercase letter")
        if not re.search(r"\d", v):
            raise ValueError("Password must contain at least one digit")
        if not re.search(r"[!@#$%^&*(),.?\":{}|<>]", v):
            raise ValueError("Password must contain at least one special character")
        return v

    @model_validator(mode='after')
    def validate_passwords_match(self) -> 'UserCreateSchema':
        """Verify passwords match"""
        if self.password != self.password_confirm:
            raise ValueError("Passwords do not match")
        return self

class UserUpdateSchema(BaseModel):
    """Schema for user updates (all fields optional)"""
    email: Optional[EmailStr] = None
    full_name: Optional[str] = Field(None, min_length=2, max_length=100)
    password: Optional[str] = Field(
        None,
        min_length=8,
        max_length=64,
        description="Must meet same requirements as creation password"
    )
    role: Optional[UserRole] = None
    status: Optional[UserStatus] = None

    @field_validator('password')
    @classmethod
    def validate_password_strength(cls, v: Optional[str]) -> Optional[str]:
        """Validate password if provided"""
        if v is None:
            return v
        return UserCreateSchema.validate_password_strength(v)

class UserResponseSchema(UserBaseSchema):
    """Schema for user responses (read-only fields)"""
    id: int
    created_at: datetime
    updated_at: datetime
    last_login: Optional[datetime]

    class Config:
        from_attributes = True  # Pydantic v2 replacement for orm_mode
        json_schema_extra = {
            "example": {
                "id": 1,
                "email": "user@example.com",
                "full_name": "John Doe",
                "role": "user",
                "status": "active",
                "created_at": "2023-01-01T00:00:00Z",
                "updated_at": "2023-01-01T00:00:00Z",
                "last_login": "2023-01-01T12:00:00Z"
            }
        }

class UserLoginSchema(BaseModel):
    """Schema for user login"""
    email: EmailStr = Field(..., example="user@example.com")
    password: str = Field(..., example="SecurePass123!")

class UserPasswordResetSchema(BaseModel):
    """Schema for password reset"""
    new_password: str = Field(
        ...,
        min_length=8,
        max_length=64,
        description="Must meet same requirements as creation password"
    )
    new_password_confirm: str = Field(..., exclude=True)
    token: str = Field(..., description="Password reset token")

    @field_validator('new_password')
    @classmethod
    def validate_password_strength(cls, v: str) -> str:
        """Validate password meets complexity requirements"""
        return UserCreateSchema.validate_password_strength(v)

    @model_validator(mode='after')
    def validate_passwords_match(self) -> 'UserPasswordResetSchema':
        """Verify passwords match"""
        if self.new_password != self.new_password_confirm:
            raise ValueError("Passwords do not match")
        return self
