# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

from flask_restx import Namespace
from api.users.users_controller import api as users_ns
# from .auth.controllers import api as auth_ns

def init_namespaces(api):
    """Initialize all API namespaces"""
    api.add_namespace(users_ns, path='/users')
    # api.add_namespace(auth_ns, path='/auth')
