# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

