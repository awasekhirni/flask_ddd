# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

import logging
import os
import json
import uuid
import asyncio
from concurrent.futures import ThreadPoolExecutor
from logging.handlers import RotatingFileHandler
from pythonjsonlogger import jsonlogger
from dotenv import load_dotenv
from flask import request, g
from typing import Optional, Dict, Any

load_dotenv()

# Constants
LOG_DIR = "logs"
os.makedirs(LOG_DIR, exist_ok=True)

# Custom Log Levels
AUDIT_LEVEL_NUM = 25
SECURITY_LEVEL_NUM = 35
logging.addLevelName(AUDIT_LEVEL_NUM, "AUDIT")
logging.addLevelName(SECURITY_LEVEL_NUM, "SECURITY")

# Add custom log methods to Logger class
def audit(self, message, *args, **kwargs):
    if self.isEnabledFor(AUDIT_LEVEL_NUM):
        self._log(AUDIT_LEVEL_NUM, message, args, **kwargs)

def security(self, message, *args, **kwargs):
    if self.isEnabledFor(SECURITY_LEVEL_NUM):
        self._log(SECURITY_LEVEL_NUM, message, args, **kwargs)

logging.Logger.audit = audit
logging.Logger.security = security

class CustomJsonFormatter(jsonlogger.JsonFormatter):
    """Enhanced JSON formatter with request context support."""

    def add_fields(self, log_record: Dict, record: logging.LogRecord, message_dict: Dict) -> None:
        super().add_fields(log_record, record, message_dict)
        log_record.update({
            "level": record.levelname,
            "name": record.name,
            "timestamp": self.formatTime(record, self.datefmt),
            "pathname": record.pathname,
            "lineno": record.lineno,
            "request_id": getattr(record, 'request_id', 'N/A'),
            "correlation_id": getattr(record, 'correlation_id', 'N/A'),
            "service": os.getenv("SERVICE_NAME", "unknown")
        })

        if hasattr(record, 'context'):
            log_record.update(record.context)

        # Include exception details if present
        if record.exc_info:
            log_record["exception"] = self.formatException(record.exc_info)

class AsyncLogHandler:
    """Wrapper for async logging operations."""

    _executor = ThreadPoolExecutor(max_workers=5)

    @classmethod
    async def log_async(cls, logger: logging.Logger, level: int, message: str, **context: Any) -> None:
        """Execute logging in a separate thread."""
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(
            cls._executor,
            lambda: logger.log(level, message, extra=context)
        )

def setup_logger(name: str) -> logging.Logger:
    """Configure and return a logger with file handlers."""

    logger = logging.getLogger(name)
    logger.setLevel(os.getenv("LOG_LEVEL", "DEBUG").upper())

    json_formatter = CustomJsonFormatter(
        fmt="%(timestamp)s %(level)s %(name)s %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S%z"
    )

    def create_handler(filename: str, level: int) -> RotatingFileHandler:
        handler = RotatingFileHandler(
            os.path.join(LOG_DIR, filename),
            maxBytes=5_000_000,
            backupCount=3,
            encoding='utf-8'
        )
        handler.setLevel(level)
        handler.setFormatter(json_formatter)
        return handler

    if not logger.handlers:
        logger.addHandler(create_handler("app.log", logging.DEBUG))
        logger.addHandler(create_handler("error.log", logging.ERROR))
        logger.addHandler(create_handler("audit.log", AUDIT_LEVEL_NUM))
        logger.addHandler(create_handler("security.log", SECURITY_LEVEL_NUM))

    logger.propagate = False
    return logger

def init_request_context() -> Dict[str, str]:
    """Initialize request context with IDs for tracing."""
    context = {
        'request_id': str(uuid.uuid4()),
        'correlation_id': request.headers.get('X-Correlation-ID', str(uuid.uuid4()))
    }
    g.update(context)
    return context

def log_with_context(
    logger: logging.Logger,
    level: int,
    message: str,
    **additional_context: Any
) -> None:
    """Log messages with full request context."""
    context = {
        'request_id': g.get('request_id', 'N/A'),
        'correlation_id': g.get('correlation_id', 'N/A'),
        **additional_context
    }
    logger.log(level, message, extra={'context': context})

# Flask-specific integration
def before_request() -> None:
    """Initialize request logging context."""
    init_request_context()

# Example usage:
# logger = setup_logger(__name__)
# log_with_context(logger, logging.INFO, "User logged in", user_id=123)
# await AsyncLogHandler.log_async(logger, logging.INFO, "Async log message")
