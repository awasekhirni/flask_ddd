# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Generic, TypeVar
from datetime import datetime

T = TypeVar('T')  # Generic type for the entity

class IAsyncBaseService(ABC, Generic[T]):
    """Asynchronous base service interface with common operations"""

    @abstractmethod
    async def get_all(self) -> List[T]:
        """Asynchronously retrieve all entities"""
        pass

    @abstractmethod
    async def get_by_id(self, id: int) -> Optional[T]:
        """Asynchronously retrieve an entity by its unique ID"""
        pass

    @abstractmethod
    async def create(self, data: Dict) -> T:
        """Asynchronously create a new entity from provided data"""
        pass

    @abstractmethod
    async def update(self, id: int, update_data: Dict) -> Optional[T]:
        """Asynchronously update an existing entity with new data"""
        pass

    @abstractmethod
    async def delete(self, id: int) -> Optional[T]:
        """Asynchronously delete an entity by ID"""
        pass

    @abstractmethod
    async def exists(self, field: str, value: str) -> bool:
        """Asynchronously check whether an entity exists based on a field"""
        pass

    @abstractmethod
    async def get_paginated(self, page: int, per_page: int) -> List[T]:
        """Asynchronously retrieve paginated entities"""
        pass

    @abstractmethod
    async def get_sorted(self, field: str, ascending: bool = True) -> List[T]:
        """Asynchronously retrieve entities sorted by a given field"""
        pass

    @abstractmethod
    async def filter(self, filters: Dict) -> List[T]:
        """Asynchronously filter entities by dynamic field criteria"""
        pass

    @abstractmethod
    async def bulk_create(self, items_data: List[Dict]) -> List[T]:
        """Asynchronously create multiple entities in bulk"""
        pass

# from typing import TypeVar, Generic, List, Optional, Dict, Any
# from sqlalchemy.ext.asyncio import AsyncSession
# from sqlalchemy.exc import SQLAlchemyError
# from shared.exceptions import NotFoundException, ValidationException, DatabaseException
# from shared.async_base_repository import AsyncBaseRepository

# ModelType = TypeVar("ModelType")  # SQLAlchemy ORM model
# IDType = TypeVar("IDType")        # Primary key type


# class AsyncBaseService(Generic[ModelType, IDType]):
#     def __init__(self, repository: AsyncBaseRepository[ModelType, IDType]):
#         self.repository = repository

#     async def get_all(self) -> List[ModelType]:
#         try:
#             return await self.repository.get_all()
#         except SQLAlchemyError as e:
#             raise DatabaseException(str(e))

#     async def get_by_id(self, id: IDType) -> ModelType:
#         try:
#             result = await self.repository.get_by_id(id)
#             if not result:
#                 raise NotFoundException("Item not found")
#             return result
#         except SQLAlchemyError as e:
#             raise DatabaseException(str(e))

#     async def create(self, obj_in: Dict[str, Any]) -> ModelType:
#         await self._validate_create(obj_in)
#         try:
#             return await self.repository.create(obj_in)
#         except SQLAlchemyError as e:
#             raise DatabaseException(str(e))

#     async def update(self, id: IDType, obj_in: Dict[str, Any]) -> ModelType:
#         await self._validate_update(obj_in)
#         try:
#             return await self.repository.update(id, obj_in)
#         except SQLAlchemyError as e:
#             raise DatabaseException(str(e))

#     async def delete(self, id: IDType) -> bool:
#         try:
#             return await self.repository.delete(id)
#         except SQLAlchemyError as e:
#             raise DatabaseException(str(e))

#     async def filter_by(self, **kwargs) -> List[ModelType]:
#         try:
#             return await self.repository.filter_by(**kwargs)
#         except SQLAlchemyError as e:
#             raise DatabaseException(str(e))

#     async def get_first_by(self, **kwargs) -> Optional[ModelType]:
#         try:
#             return await self.repository.get_first_by(**kwargs)
#         except SQLAlchemyError as e:
#             raise DatabaseException(str(e))

#     # Overrideable hooks
#     async def _validate_create(self, obj_in: Dict[str, Any]) -> None:
#         pass

#     async def _validate_update(self, obj_in: Dict[str, Any]) -> None:
#         pass



# #integration example
# # from application.services.async_base_service import AsyncBaseService
# # from infrastructure.repositories.user_repository_async import UserRepository
# # from domain.users.models import User
# # from shared.exceptions import ValidationException
# # from typing import Dict, Any


# # class UserService(AsyncBaseService[User, str]):
# #     def __init__(self, repository: UserRepository):
# #         super().__init__(repository)

# #     async def _validate_create(self, obj_in: Dict[str, Any]) -> None:
# #         if not obj_in.get("email") or not obj_in.get("password"):
# #             raise ValidationException("Email and password required")

# #         existing = await self.repository.get_first_by(email=obj_in["email"])
# #         if existing:
# #             raise ValidationException("Email already registered")
