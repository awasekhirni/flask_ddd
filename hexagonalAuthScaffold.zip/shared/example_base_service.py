# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

from typing import TypeVar, Generic, List, Optional, Dict, Any, Union, Type
from sqlalchemy.orm import Session
from shared.exceptions import (
    NotFoundException,
    ValidationException,
    DatabaseException
)
from shared.base_repository import BaseRepository
from pydantic import BaseModel, ValidationError
from datetime import datetime
import logging
from functools import wraps

logger = logging.getLogger(__name__)

ModelType = TypeVar('ModelType')  # SQLAlchemy model
IDType = TypeVar('IDType')        # Primary key type (e.g., str, int)
CreateSchemaType = TypeVar('CreateSchemaType', bound=BaseModel)
UpdateSchemaType = TypeVar('UpdateSchemaType', bound=BaseModel)

class BaseService(Generic[ModelType, IDType, CreateSchemaType, UpdateSchemaType]):
    """
    Generic base service with common CRUD operations and validation.

    Types:
    - ModelType: SQLAlchemy model class
    - IDType: Primary key type (str/int)
    - CreateSchemaType: Pydantic model for creation
    - UpdateSchemaType: Pydantic model for updates
    """

    def __init__(self, repository: BaseRepository[ModelType, IDType]):
        self.repository = repository

    def get_all(
        self,
        skip: int = 0,
        limit: int = 100,
        order_by: Optional[str] = None,
        desc_order: bool = False,
        **filters: Any
    ) -> List[ModelType]:
        """Get all entities with optional filtering and pagination."""
        return self.repository.get_all(
            skip=skip,
            limit=limit,
            order_by=order_by,
            desc_order=desc_order,
            **filters
        )

    def get_by_id(self, id: IDType) -> ModelType:
        """Get entity by ID."""
        entity = self.repository.get_by_id(id)
        if not entity:
            raise NotFoundException(f"Entity with id {id} not found")
        return entity

    def create(self, obj_in: Union[CreateSchemaType, Dict[str, Any]]) -> ModelType:
        """Create a new entity with validation."""
        try:
            if isinstance(obj_in, dict):
                obj_in = self._convert_to_create_schema(obj_in)
            self._validate_create(obj_in)
            return self.repository.create(obj_in.dict())
        except ValidationError as e:
            logger.error(f"Validation error: {str(e)}")
            raise ValidationException(
                message="Invalid data provided",
                details=e.errors()
            )
        except Exception as e:
            logger.error(f"Error creating entity: {str(e)}")
            raise DatabaseException(
                message="Failed to create entity",
                details={"error": str(e)}
            )

    def update(
        self,
        id: IDType,
        obj_in: Union[UpdateSchemaType, Dict[str, Any]],
        exclude_unset: bool = True
    ) -> ModelType:
        """Update an existing entity with validation."""
        try:
            if isinstance(obj_in, dict):
                obj_in = self._convert_to_update_schema(obj_in)
            self._validate_update(id, obj_in)
            return self.repository.update(
                id,
                obj_in.dict(exclude_unset=exclude_unset)
            )
        except ValidationError as e:
            logger.error(f"Validation error: {str(e)}")
            raise ValidationException(
                message="Invalid data provided",
                details=e.errors()
            )
        except Exception as e:
            logger.error(f"Error updating entity: {str(e)}")
            raise DatabaseException(
                message="Failed to update entity",
                details={"error": str(e)}
            )

    def delete(self, id: IDType) -> bool:
        """Delete an entity."""
        try:
            return self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting entity: {str(e)}")
            raise DatabaseException(
                message="Failed to delete entity",
                details={"error": str(e)}
            )

    def filter_by(self, **kwargs: Any) -> List[ModelType]:
        """Filter entities by given criteria."""
        return self.repository.filter_by(**kwargs)

    def get_first_by(self, **kwargs: Any) -> Optional[ModelType]:
        """Get first entity matching criteria."""
        return self.repository.get_first_by(**kwargs)

    def exists(self, **kwargs: Any) -> bool:
        """Check if any entity matches criteria."""
        return self.repository.exists(**kwargs)

    def count(self, **kwargs: Any) -> int:
        """Count entities matching criteria."""
        return self.repository.count(**kwargs)

    # --- Hooks to override in child services ---
    def _validate_create(self, obj_in: CreateSchemaType) -> None:
        """
        Validate data before creation.
        Override to add domain-specific validation logic.
        """
        pass

    def _validate_update(self, id: IDType, obj_in: UpdateSchemaType) -> None:
        """
        Validate data before update.
        Override to add domain-specific validation logic.
        """
        pass

    def _convert_to_create_schema(self, data: Dict[str, Any]) -> CreateSchemaType:
        """
        Convert dict to CreateSchemaType.
        Override if you need custom conversion logic.
        """
        return CreateSchemaType(**data)

    def _convert_to_update_schema(self, data: Dict[str, Any]) -> UpdateSchemaType:
        """
        Convert dict to UpdateSchemaType.
        Override if you need custom conversion logic.
        """
        return UpdateSchemaType(**data)

    # --- Decorators ---
    @staticmethod
    def validate_input(schema: Type[BaseModel]):
        """
        Decorator to validate service method inputs.
        Usage:
        @validate_input(UserCreateSchema)
        def create_user(self, data): ...
        """
        def decorator(f):
            @wraps(f)
            def wrapper(service, data: Union[Dict, BaseModel], *args, **kwargs):
                if isinstance(data, dict):
                    data = schema(**data)
                elif not isinstance(data, schema):
                    raise ValidationException(
                        message=f"Expected {schema.__name__}",
                        details={"invalid_type": type(data).__name__}
                    )
                return f(service, data, *args, **kwargs)
            return wrapper
        return decorator
