# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

# shared/exceptions.py
from flask import jsonify, request, g
from werkzeug.exceptions import HTTPException
import logging
from typing import Dict, Any, Optional, Type, Union, Tuple
from http import HTTPStatus
from dataclasses import dataclass
from flask_babel import _
from functools import wraps

logger = logging.getLogger(__name__)

@dataclass
class ErrorResponse:
    """Standardized error response structure."""
    message: str
    code: int
    error_code: str
    documentation_link: str = "https://example.com/docs/errors"
    details: Optional[Dict[str, Any]] = None
    error_type: Optional[str] = None
    request_id: Optional[str] = None
    correlation_id: Optional[str] = None

class AppException(Exception):
    """Base exception class for application-specific exceptions"""
    status_code: int = HTTPStatus.INTERNAL_SERVER_ERROR
    error_type: str = "server_error"
    message: str = _("An unexpected error occurred")
    error_code: str = "ERR_000"
    log_level: int = logging.ERROR

    def __init__(
        self,
        message: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        error_type: Optional[str] = None,
        error_code: Optional[str] = None,
        **context: Any
    ):
        self.message = message or self.message
        self.details = details or {}
        self.error_type = error_type or self.error_type
        self.error_code = error_code or self.error_code
        self.context = context
        super().__init__(self.message)

    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to API response format."""
        return {
            "error": self.error_type,
            "message": self.message,
            "error_code": self.error_code,
            "status_code": self.status_code,
            "details": self.details,
            "request_id": g.get('request_id'),
            "correlation_id": g.get('correlation_id')
        }

    def to_response(self) -> Tuple[Any, int]:
        """Create Flask response tuple."""
        return jsonify({"status": "error", **self.to_dict()}), self.status_code

    def log(self) -> None:
        """Log the exception with context."""
        logger.log(
            self.log_level,
            f"{self.error_type}: {self.message}",
            extra={
                "error_code": self.error_code,
                "status_code": self.status_code,
                "path": request.path,
                "method": request.method,
                "user": getattr(g, 'user', None),
                "request_id": g.get('request_id'),
                "correlation_id": g.get('correlation_id'),
                **self.context,
                **self.details
            }
        )

# ======================
# CORE EXCEPTION CLASSES
# ======================

class BadRequestException(AppException):
    status_code = HTTPStatus.BAD_REQUEST
    error_type = "bad_request"
    message = _("Invalid request parameters")
    error_code = "ERR_400"

class UnauthorizedException(AppException):
    status_code = HTTPStatus.UNAUTHORIZED
    error_type = "unauthorized"
    message = _("Authentication required")
    error_code = "ERR_401"

class ForbiddenException(AppException):
    status_code = HTTPStatus.FORBIDDEN
    error_type = "forbidden"
    message = _("Permission denied")
    error_code = "ERR_403"

class NotFoundException(AppException):
    status_code = HTTPStatus.NOT_FOUND
    error_type = "not_found"
    message = _("Resource not found")
    error_code = "ERR_404"

class ConflictException(AppException):
    status_code = HTTPStatus.CONFLICT
    error_type = "conflict"
    message = _("Resource conflict occurred")
    error_code = "ERR_409"

class ValidationException(BadRequestException):
    error_type = "validation_error"
    message = _("Validation failed")
    error_code = "ERR_VALIDATION"

class RateLimitException(AppException):
    status_code = HTTPStatus.TOO_MANY_REQUESTS
    error_type = "rate_limit_exceeded"
    message = _("Too many requests")
    error_code = "ERR_429"
    log_level = logging.WARNING

class ServiceUnavailableException(AppException):
    status_code = HTTPStatus.SERVICE_UNAVAILABLE
    error_type = "service_unavailable"
    message = _("Service temporarily unavailable")
    error_code = "ERR_503"

# ======================
# DOMAIN-SPECIFIC EXCEPTIONS
# ======================

class UserNotFoundException(NotFoundException):
    error_type = "user_not_found"
    message = _("User not found")
    error_code = "ERR_USER_404"

class UserAlreadyExistsException(ConflictException):
    error_type = "user_already_exists"
    message = _("User already exists")
    error_code = "ERR_USER_EXISTS"

class AuthenticationFailedException(UnauthorizedException):
    error_type = "authentication_failed"
    message = _("Authentication failed")
    error_code = "ERR_AUTH_FAILED"

class InvalidCredentialsException(UnauthorizedException):
    error_type = "invalid_credentials"
    message = _("Invalid credentials provided")
    error_code = "ERR_AUTH_FAILED"

class ExpiredTokenException(UnauthorizedException):
    error_type = "expired_token"
    message = _("Authentication token has expired")
    error_code = "ERR_TOKEN_EXPIRED"

class InvalidUserDataException(ValidationException):
    error_type = "invalid_user_data"
    message = _("Invalid user data provided")
    error_code = "ERR_USER_DATA"

class PermissionDeniedException(ForbiddenException):
    error_type = "permission_denied"
    message = _("Permission denied for this operation")
    error_code = "ERR_PERMISSION_DENIED"

class AccountLockedException(ForbiddenException):
    status_code = 423  # Locked
    error_type = "account_locked"
    message = _("Account is locked")
    error_code = "ERR_ACCOUNT_LOCKED"

# ======================
# SECURITY EXCEPTIONS
# ======================

class PasswordHashingError(AppException):
    error_type = "password_hashing_error"
    message = _("Password hashing failed")
    error_code = "ERR_PASSWORD_HASH"

class TokenValidationError(UnauthorizedException):
    error_type = "token_validation_error"
    message = _("Token validation failed")
    error_code = "ERR_TOKEN_INVALID"

# ======================
# DATABASE EXCEPTIONS
# ======================

class DatabaseError(AppException):
    error_type = "database_error"
    message = _("Database operation failed")
    error_code = "ERR_DB_500"

class RecordNotFoundError(DatabaseError, NotFoundException):
    error_type = "record_not_found"
    message = _("Database record not found")
    error_code = "ERR_DB_404"

class ConstraintViolationError(DatabaseError, ConflictException):
    error_type = "constraint_violation"
    message = _("Database constraint violation")
    error_code = "ERR_DB_CONSTRAINT"

# ======================
# ERROR HANDLERS
# ======================

def handle_api_exception(error: AppException) -> Tuple[Any, int]:
    """Handle AppException and its subclasses."""
    error.log()
    return error.to_response()

def handle_http_exception(error: HTTPException) -> Tuple[Any, int]:
    """Handle Werkzeug HTTP exceptions."""
    response = ErrorResponse(
        message=error.description,
        code=error.code,
        error_type="http_error",
        error_code=f"ERR_{error.code}",
        request_id=g.get('request_id'),
        correlation_id=g.get('correlation_id')
    )

    logger.warning(
        f"HTTPError {error.code}: {error.name}",
        extra={
            "status_code": error.code,
            "path": request.path,
            "request_id": g.get('request_id'),
            "correlation_id": g.get('correlation_id')
        }
    )

    return jsonify({"status": "error", **response.__dict__}), error.code

def handle_unexpected_error(error: Exception) -> Tuple[Any, int]:
    """Handle unexpected exceptions."""
    response = ErrorResponse(
        message=_("An unexpected error occurred"),
        code=HTTPStatus.INTERNAL_SERVER_ERROR,
        error_type="internal_server_error",
        error_code="ERR_500",
        request_id=g.get('request_id'),
        correlation_id=g.get('correlation_id')
    )

    logger.exception(
        "Unexpected error: %s", str(error),
        extra={
            "request_id": g.get('request_id'),
            "correlation_id": g.get('correlation_id'),
            "path": request.path
        }
    )

    return jsonify({"status": "error", **response.__dict__}), HTTPStatus.INTERNAL_SERVER_ERROR

def register_error_handlers(app):
    """Register all error handlers with Flask application."""
    app.errorhandler(AppException)(handle_api_exception)
    app.errorhandler(HTTPException)(handle_http_exception)
    app.errorhandler(Exception)(handle_unexpected_error)

# ======================
# DECORATORS
# ======================

def catch_and_handle(exceptions: Union[Type[Exception], Tuple[Type[Exception], ...]]):
    """Decorator to catch and handle specific exceptions."""
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            try:
                return f(*args, **kwargs)
            except exceptions as e:
                if isinstance(e, AppException):
                    return handle_api_exception(e)
                return handle_unexpected_error(e)
        return wrapper
    return decorator
