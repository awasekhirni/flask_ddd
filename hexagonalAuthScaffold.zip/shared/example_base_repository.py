# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

from typing import TypeVar, Generic, List, Optional, Type, Dict, Any, Union, Tuple
from sqlalchemy.orm import Session, Query
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from sqlalchemy import asc, desc, func, and_
from shared.exceptions import (
    DatabaseException,
    NotFoundException,
    ConflictException
)
import logging
from contextlib import contextmanager
from datetime import datetime
from pydantic import BaseModel

logger = logging.getLogger(__name__)

ModelType = TypeVar('ModelType')  # SQLAlchemy model
IDType = TypeVar('IDType')        # Primary key type (usually str or int)
CreateSchemaType = TypeVar('CreateSchemaType', bound=BaseModel)
UpdateSchemaType = TypeVar('UpdateSchemaType', bound=BaseModel)

class BaseRepository(Generic[ModelType, IDType]):
    """Generic base repository with common CRUD operations."""

    def __init__(self, model: Type[ModelType], session: Session):
        self.model = model
        self.session = session

    @contextmanager
    def _handle_db_errors(self):
        """Context manager for handling database errors."""
        try:
            yield
            self.session.flush()
        except IntegrityError as e:
            logger.error(f"Integrity error: {str(e)}", exc_info=True)
            self.session.rollback()
            raise ConflictException(
                message="Database integrity error",
                details={"db_error": str(e.orig)}
            ) from e
        except SQLAlchemyError as e:
            logger.error(f"Database error: {str(e)}", exc_info=True)
            self.session.rollback()
            raise DatabaseException(
                message="Database operation failed",
                details={"db_error": str(e)}
            ) from e
        except Exception as e:
            logger.error(f"Unexpected error: {str(e)}", exc_info=True)
            self.session.rollback()
            raise DatabaseException(
                message="Unexpected database error",
                details={"error": str(e)}
            ) from e

    def _apply_filters(self, query: Query, filters: Dict[str, Any]) -> Query:
        """Apply filters to query."""
        for field, value in filters.items():
            if value is None:
                continue
            if isinstance(value, list):
                query = query.filter(getattr(self.model, field).in_(value))
            elif isinstance(value, dict):
                if 'gt' in value:
                    query = query.filter(getattr(self.model, field) > value['gt'])
                if 'gte' in value:
                    query = query.filter(getattr(self.model, field) >= value['gte'])
                if 'lt' in value:
                    query = query.filter(getattr(self.model, field) < value['lt'])
                if 'lte' in value:
                    query = query.filter(getattr(self.model, field) <= value['lte'])
            else:
                query = query.filter(getattr(self.model, field) == value)
        return query

    def get_by_id(self, id: IDType) -> ModelType:
        """Get a single record by primary key."""
        with self._handle_db_errors():
            instance = self.session.get(self.model, id)
            if not instance:
                raise NotFoundException(
                    f"{self.model.__name__} with id {id} not found"
                )
            return instance

    def get_all(
        self,
        skip: int = 0,
        limit: int = 100,
        order_by: Optional[str] = None,
        desc_order: bool = False,
        **filters: Any
    ) -> List[ModelType]:
        """Get all records with optional filtering and pagination."""
        with self._handle_db_errors():
            query = self.session.query(self.model)
            query = self._apply_filters(query, filters)

            if order_by:
                column = getattr(self.model, order_by)
                query = query.order_by(desc(column) if desc_order else asc(column))

            return query.offset(skip).limit(limit).all()

    def count(self, **filters: Any) -> int:
        """Count records matching filters."""
        with self._handle_db_errors():
            query = self.session.query(func.count()).select_from(self.model)
            query = self._apply_filters(query, filters)
            return query.scalar()

    def exists(self, **filters: Any) -> bool:
        """Check if any record matches filters."""
        return self.count(**filters) > 0

    def create(self, obj_in: Union[Dict[str, Any], CreateSchemaType]) -> ModelType:
        """Create a new record."""
        if isinstance(obj_in, BaseModel):
            obj_in = obj_in.dict()

        with self._handle_db_errors():
            instance = self.model(**obj_in)
            self.session.add(instance)
            self.session.commit()
            self.session.refresh(instance)
            return instance

    def bulk_create(self, objects: List[Union[Dict[str, Any], CreateSchemaType]]) -> List[ModelType]:
        """Create multiple records in bulk."""
        with self._handle_db_errors():
            dict_objects = [obj.dict() if isinstance(obj, BaseModel) else obj for obj in objects]
            instances = [self.model(**obj) for obj in dict_objects]
            self.session.bulk_save_objects(instances)
            self.session.commit()
            return instances

    def update(
        self,
        id: IDType,
        obj_in: Union[Dict[str, Any], UpdateSchemaType],
        exclude_unset: bool = False
    ) -> ModelType:
        """Update a record."""
        if isinstance(obj_in, BaseModel):
            obj_in = obj_in.dict(exclude_unset=exclude_unset)

        with self._handle_db_errors():
            instance = self.get_by_id(id)
            for field, value in obj_in.items():
                setattr(instance, field, value)
            if hasattr(instance, 'updated_at'):
                instance.updated_at = datetime.utcnow()
            self.session.commit()
            self.session.refresh(instance)
            return instance

    def delete(self, id: IDType) -> bool:
        """Delete a record."""
        with self._handle_db_errors():
            instance = self.get_by_id(id)
            self.session.delete(instance)
            self.session.commit()
            return True

    def soft_delete(self, id: IDType) -> ModelType:
        """Soft delete a record (sets deleted_at timestamp)."""
        with self._handle_db_errors():
            instance = self.get_by_id(id)
            if hasattr(instance, 'deleted_at'):
                instance.deleted_at = datetime.utcnow()
                self.session.commit()
                self.session.refresh(instance)
                return instance
            raise DatabaseException(
                message="Model does not support soft deletion",
                details={"model": self.model.__name__}
            )

    def filter_by(self, **kwargs: Any) -> List[ModelType]:
        """Filter records by given criteria."""
        with self._handle_db_errors():
            return self.session.query(self.model).filter_by(**kwargs).all()

    def get_first_by(self, **kwargs: Any) -> Optional[ModelType]:
        """Get first record matching criteria."""
        with self._handle_db_errors():
            return self.session.query(self.model).filter_by(**kwargs).first()

    def get_or_create(
        self,
        defaults: Optional[Dict[str, Any]] = None,
        **kwargs: Any
    ) -> Tuple[ModelType, bool]:
        """Get or create a record."""
        with self._handle_db_errors():
            instance = self.get_first_by(**kwargs)
            if instance:
                return instance, False

            create_data = kwargs.copy()
            if defaults:
                create_data.update(defaults)

            instance = self.model(**create_data)
            self.session.add(instance)
            self.session.commit()
            self.session.refresh(instance)
            return instance, True
