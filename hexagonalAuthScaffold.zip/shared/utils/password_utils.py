# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

import bcrypt
from typing import Union
from infrastructure.exceptions import PasswordHashingError

# Cost factor for bcrypt (higher is more secure but slower)
BCRYPT_ROUNDS = 12

def hash_password(password: str) -> str:
    """
    Hash a password for storage in the database.

    Args:
        password: The plain text password to hash

    Returns:
        str: The hashed password as a string

    Raises:
        PasswordHashingError: If hashing fails
    """
    try:
        if not password:
            raise ValueError("Password cannot be empty")

        # Generate salt and hash the password
        salt = bcrypt.gensalt(rounds=BCRYPT_ROUNDS)
        hashed_bytes = bcrypt.hashpw(password.encode('utf-8'), salt)
        return hashed_bytes.decode('utf-8')
    except Exception as e:
        raise PasswordHashingError(f"Failed to hash password: {str(e)}")

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Verify a password against its hashed version.

    Args:
        plain_password: The password to verify
        hashed_password: The stored hashed password

    Returns:
        bool: True if passwords match, False otherwise

    Raises:
        PasswordHashingError: If verification fails
    """
    try:
        if not plain_password or not hashed_password:
            return False

        # BCrypt handles the salt extraction and comparison
        return bcrypt.checkpw(
            plain_password.encode('utf-8'),
            hashed_password.encode('utf-8')
        )
    except Exception as e:
        raise PasswordHashingError(f"Password verification failed: {str(e)}")

def is_password_strong(password: str) -> Union[bool, str]:
    """
    Check if a password meets strength requirements.

    Args:
        password: The password to check

    Returns:
        Union[bool, str]: True if strong, or error message if weak
    """
    if len(password) < 8:
        return "Password must be at least 8 characters long"
    if not any(c.isupper() for c in password):
        return "Password must contain at least one uppercase letter"
    if not any(c.islower() for c in password):
        return "Password must contain at least one lowercase letter"
    if not any(c.isdigit() for c in password):
        return "Password must contain at least one digit"
    if not any(c in '!@#$%^&*()_+-=[]{}|;:,.<>?/' for c in password):
        return "Password must contain at least one special character"
    return True
