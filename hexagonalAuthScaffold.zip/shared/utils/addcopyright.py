# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

import os

def add_copyright_to_file(file_path, user_string):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            original_content = f.read()

        # Prepare the comment
        comment_lines = ['# ' + line if line.strip() != '' else '#' for line in user_string.strip().split('\n')]
        copyright_comment = '\n'.join(comment_lines)

        # Check if the comment already exists to avoid duplication
        if original_content.startswith(comment_lines[0]):
            print(f"Skipped (already modified): {file_path}")
            return

        new_content = f"{copyright_comment}\n\n{original_content}"

        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(new_content)

        print(f"✔ Modified: {file_path}")

    except Exception as e:
        print(f"❌ Error processing {file_path}: {e}")

def process_directory(root_dir, user_string):
    for dirpath, _, filenames in os.walk(root_dir):
        for filename in filenames:
            if filename.endswith('.py'):
                full_path = os.path.join(dirpath, filename)
                add_copyright_to_file(full_path, user_string)

if __name__ == "__main__":
    root_dir = input("Enter the root directory to scan: ").strip()
    print("Enter your custom copyright:")
    user_string = ""
    while True:
        try:
            line = input()
            if line == "":
                break
            user_string += line + '\n'
        except EOFError:
            break

    if not os.path.isdir(root_dir):
        print(f"Error: '{root_dir}' is not a valid directory.")
    else:
        process_directory(root_dir, user_string)


#Copyright (C) 2025 β ORI Inc.
#Written by Awase Khirni Syed 2025
