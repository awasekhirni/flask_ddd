# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any, Generic, TypeVar
from datetime import datetime

T = TypeVar('T')  # Generic type for the entity

class IAsyncBaseRepository(ABC, Generic[T]):
    """Asynchronous base repository interface with common CRUD operations"""

    @abstractmethod
    async def get_all(self, *, skip: int = 0, limit: int = 100) -> List[T]:
        """Retrieve all entities asynchronously with pagination"""
        pass

    @abstractmethod
    async def get(self, id: int) -> Optional[T]:
        """Retrieve a specific entity by ID asynchronously"""
        pass

    @abstractmethod
    async def create(self, data: Dict[str, Any]) -> T:
        """Create a new entity asynchronously from dictionary data"""
        pass

    @abstractmethod
    async def update(self, id: int, data: Dict[str, Any]) -> Optional[T]:
        """Update an existing entity asynchronously from dictionary data"""
        pass

    @abstractmethod
    async def delete(self, id: int) -> bool:
        """Delete an entity by ID asynchronously, returns success status"""
        pass

    @abstractmethod
    async def count(self, **filters: Any) -> int:
        """Count the number of entities matching filters asynchronously"""
        pass

    @abstractmethod
    async def exists(self, **filters: Any) -> bool:
        """Check if an entity exists based on filters asynchronously"""
        pass

    @abstractmethod
    async def filter(self, *conditions: Any, skip: int = 0, limit: int = 100) -> List[T]:
        """Filter entities based on conditions asynchronously"""
        pass

    @abstractmethod
    async def get_by_field(self, field_name: str, value: Any) -> Optional[T]:
        """Get an entity by field-value pair asynchronously"""
        pass

    @abstractmethod
    async def filter_by_fields(self, fields: Dict[str, Any], *, skip: int = 0, limit: int = 100) -> List[T]:
        """Filter entities by multiple fields asynchronously with pagination"""
        pass

    @abstractmethod
    async def bulk_create(self, items_data: List[Dict[str, Any]]) -> List[T]:
        """Bulk create entities asynchronously from dictionary data"""
        pass

    @abstractmethod
    async def bulk_update(self, updates: List[Dict[str, Any]]) -> List[T]:
        """Bulk update entities asynchronously from dictionary data"""
        pass



# from sqlalchemy.ext.asyncio import AsyncSession
# from sqlalchemy.future import select
# from typing import Generic, TypeVar, Type, List, Optional, Dict, Any
# from sqlalchemy import update as sqlalchemy_update, delete as sqlalchemy_delete

# ModelType = TypeVar("ModelType")
# IDType = TypeVar("IDType")


# class AsyncBaseRepository(Generic[ModelType, IDType]):
#     def __init__(self, model: Type[ModelType], session: AsyncSession):
#         self.model = model
#         self.session = session

#     async def get_all(self) -> List[ModelType]:
#         result = await self.session.execute(select(self.model))
#         return result.scalars().all()

#     async def get_by_id(self, id: IDType) -> Optional[ModelType]:
#         return await self.session.get(self.model, id)

#     async def create(self, obj_in: Dict[str, Any]) -> ModelType:
#         db_obj = self.model(**obj_in)
#         self.session.add(db_obj)
#         await self.session.commit()
#         await self.session.refresh(db_obj)
#         return db_obj

#     async def update(self, id: IDType, obj_in: Dict[str, Any]) -> Optional[ModelType]:
#         db_obj = await self.get_by_id(id)
#         if not db_obj:
#             return None
#         for field, value in obj_in.items():
#             setattr(db_obj, field, value)
#         await self.session.commit()
#         await self.session.refresh(db_obj)
#         return db_obj

#     async def delete(self, id: IDType) -> bool:
#         db_obj = await self.get_by_id(id)
#         if not db_obj:
#             return False
#         await self.session.delete(db_obj)
#         await self.session.commit()
#         return True

#     async def filter_by(self, **kwargs) -> List[ModelType]:
#         result = await self.session.execute(select(self.model).filter_by(**kwargs))
#         return result.scalars().all()

#     async def get_first_by(self, **kwargs) -> Optional[ModelType]:
#         result = await self.session.execute(select(self.model).filter_by(**kwargs))
#         return result.scalars().first()
