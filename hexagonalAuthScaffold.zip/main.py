# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed February 2025
#
from flask import Flask
from flask_restx import Api
from infrastructure.database.db import async_db
from api.namespaces import init_namespaces
import asyncio
import threading
from concurrent.futures import ThreadPoolExecutor

def create_app():
    """Application factory with proper async initialization"""
    app = Flask(__name__)

    # Initialize configuration
    app.config.from_object('config.configurations.config')

    # Initialize database in a thread-safe manner
    def initialize_database():
        # Create a new event loop for this thread
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        try:
            loop.run_until_complete(async_db.init_db())
        except Exception as e:
            app.logger.critical(f"Database initialization failed: {str(e)}")
            raise RuntimeError(f"Database initialization failed: {str(e)}") from e
        finally:
            loop.close()

    # Use ThreadPoolExecutor to manage the initialization
    with ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(initialize_database)
        future.result()  # Wait for initialization to complete

    # Configure API
    api = Api(
        title='Async User Management API',
        version='1.0',
        description='API with async database operations',
        doc='/docs',
        validate=True
    )

    # Initialize namespaces - must happen before init_app
    init_namespaces(api)

    # Register API with app
    api.init_app(app)

    @app.teardown_appcontext
    def shutdown(exception=None):
        """Close database connection on app teardown"""
        if hasattr(async_db, 'engine') and async_db.engine:
            # Run async cleanup in a separate thread
            def cleanup():
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                try:
                    loop.run_until_complete(async_db.close())
                finally:
                    loop.close()

            threading.Thread(target=cleanup).start()

    return app

app = create_app()

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)
