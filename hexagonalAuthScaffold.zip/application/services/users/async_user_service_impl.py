# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025

from datetime import datetime
from typing import List, Optional, Dict, Any
from domain.users.users_entity import Users as User
from domain.users.async_user_repository_interface import IAsyncUserRepository
from domain.users.async_user_service_interface import IAsyncUserService
from infrastructure.repositories.users.async_user_repository_impl import UserRepositoryImpl
from shared.exceptions import NotFoundException, AuthenticationFailedException
from shared.logger import logging as logger  # Fixed import


class UserServiceImpl(IAsyncUserService):
    """Implementation of asynchronous user service"""

    def __init__(self, user_repository: IAsyncUserRepository = None):
        self._user_repository = user_repository or UserRepositoryImpl()

    # Authentication methods
    async def authenticate_user(self, email: str, password: str) -> Optional[User]:
        """Authenticate user with email and password"""
        try:
            user = await self._user_repository.get_user_by_email(email)
            if not user:
                raise AuthenticationFailedException("Invalid email or password")

            # In a real implementation, you would verify the hashed password
            # For example: if not verify_password(password, user.hashed_password):
            if user.hashed_password != password:
                raise AuthenticationFailedException("Invalid email or password")

            return user
        except Exception as e:
            logger.error(f"Authentication failed for email {email}: {str(e)}")
            raise

    # CRUD operations (inherited from IAsyncBaseService)
    async def create(self, entity: User) -> User:
        """Create a new user"""
        try:
            return await self._user_repository.create_user(entity.__dict__)
        except Exception as e:
            logger.error(f"Error creating user: {str(e)}")
            raise

    async def get_by_id(self, entity_id: int) -> Optional[User]:
        """Get user by ID"""
        try:
            user = await self._user_repository.get_user(entity_id)
            if not user:
                raise NotFoundException(f"User with ID {entity_id} not found")
            return user
        except Exception as e:
            logger.error(f"Error getting user by ID {entity_id}: {str(e)}")
            raise

    async def get_all(self, *, skip: int = 0, limit: int = 100) -> List[User]:
        """Get all users with pagination"""
        try:
            return await self._user_repository.get_all_users(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all users: {str(e)}")
            raise

    async def update(self, entity_id: int, entity: User) -> Optional[User]:
        """Update a user"""
        try:
            return await self._user_repository.update_user(entity_id, entity.__dict__)
        except Exception as e:
            logger.error(f"Error updating user with ID {entity_id}: {str(e)}")
            raise

    async def delete(self, entity_id: int) -> bool:
        """Delete a user"""
        try:
            return await self._user_repository.delete_user(entity_id)
        except Exception as e:
            logger.error(f"Error deleting user with ID {entity_id}: {str(e)}")
            raise

    # User-specific methods
    async def get_user_by_email(self, email: str) -> Optional[User]:
        """Get user by email"""
        try:
            user = await self._user_repository.get_user_by_email(email)
            if not user:
                raise NotFoundException(f"User with email {email} not found")
            return user
        except Exception as e:
            logger.error(f"Error getting user by email {email}: {str(e)}")
            raise

    async def get_user_by_username(self, username: str) -> Optional[User]:
        """Get user by username"""
        try:
            user = await self._user_repository.get_user_by_username(username)
            if not user:
                raise NotFoundException(f"User with username {username} not found")
            return user
        except Exception as e:
            logger.error(f"Error getting user by username {username}: {str(e)}")
            raise

    async def get_first_10_users(self) -> List[User]:
        """Get first 10 users"""
        try:
            return await self._user_repository.get_first_n_users(10)
        except Exception as e:
            logger.error(f"Error getting first 10 users: {str(e)}")
            raise

    # Role management
    async def assign_role(self, user_id: int, role: str) -> Optional[User]:
        """Assign role to user"""
        try:
            user = await self._user_repository.assign_role_to_user(user_id, role)
            if not user:
                raise NotFoundException(f"User with ID {user_id} not found")
            return user
        except Exception as e:
            logger.error(f"Error assigning role {role} to user {user_id}: {str(e)}")
            raise

    async def remove_role(self, user_id: int, role: str) -> Optional[User]:
        """Remove role from user"""
        try:
            user = await self._user_repository.remove_role_from_user(user_id, role)
            if not user:
                raise NotFoundException(f"User with ID {user_id} not found")
            return user
        except Exception as e:
            logger.error(f"Error removing role {role} from user {user_id}: {str(e)}")
            raise

    # Permission management
    async def assign_permissions(self, user_id: int, permissions: List[str]) -> Optional[User]:
        """Assign permissions to user"""
        try:
            user = await self._user_repository.assign_permissions_to_user(user_id, permissions)
            if not user:
                raise NotFoundException(f"User with ID {user_id} not found")
            return user
        except Exception as e:
            logger.error(f"Error assigning permissions to user {user_id}: {str(e)}")
            raise

    async def remove_permissions(self, user_id: int, permissions: List[str]) -> Optional[User]:
        """Remove permissions from user"""
        try:
            user = await self._user_repository.remove_permissions_from_user(user_id, permissions)
            if not user:
                raise NotFoundException(f"User with ID {user_id} not found")
            return user
        except Exception as e:
            logger.error(f"Error removing permissions from user {user_id}: {str(e)}")
            raise

    # Account management
    async def reset_password(self, user_id: int, new_password: str) -> bool:
        """Reset user password"""
        try:
            # In production, you would hash the password before storing
            return await self._user_repository.reset_user_password(user_id, new_password)
        except Exception as e:
            logger.error(f"Error resetting password for user {user_id}: {str(e)}")
            raise

    async def change_status(self, user_id: int, status: str) -> Optional[User]:
        """Change user status"""
        try:
            user = await self._user_repository.change_user_status(user_id, status)
            if not user:
                raise NotFoundException(f"User with ID {user_id} not found")
            return user
        except Exception as e:
            logger.error(f"Error changing status for user {user_id}: {str(e)}")
            raise

    # Profile management
    async def update_profile(self, user_id: int, profile_data: Dict[str, Any]) -> Optional[User]:
        """Update user profile"""
        try:
            user = await self._user_repository.update_user_profile(user_id, profile_data)
            if not user:
                raise NotFoundException(f"User with ID {user_id} not found")
            return user
        except Exception as e:
            logger.error(f"Error updating profile for user {user_id}: {str(e)}")
            raise

    # Reporting methods
    async def get_users_by_registration_period(self, start_date: str, end_date: str) -> List[User]:
        """Get users registered between dates"""
        try:
            start_dt = datetime.fromisoformat(start_date)
            end_dt = datetime.fromisoformat(end_date)
            return await self._user_repository.get_users_by_registration_date_range(start_dt, end_dt)
        except ValueError as e:
            logger.error(f"Invalid date format: {str(e)}")
            raise ValueError("Invalid date format. Use ISO format (YYYY-MM-DD)")
        except Exception as e:
            logger.error(f"Error getting users by registration period: {str(e)}")
            raise

    async def get_user_last_login(self, user_id: int) -> Optional[datetime]:
        """Get user's last login timestamp"""
        try:
            last_login = await self._user_repository.get_user_last_login(user_id)
            if not last_login:
                raise NotFoundException(f"User with ID {user_id} not found or never logged in")
            return last_login
        except Exception as e:
            logger.error(f"Error getting last login for user {user_id}: {str(e)}")
            raise

    # Additional utility methods
    async def user_exists(self, **filters: Any) -> bool:
        """Check if user exists with given filters"""
        try:
            return await self._user_repository.user_exists(**filters)
        except Exception as e:
            logger.error(f"Error checking user existence: {str(e)}")
            raise

    async def count_users(self, **filters: Any) -> int:
        """Count users matching filters"""
        try:
            return await self._user_repository.count_users(**filters)
        except Exception as e:
            logger.error(f"Error counting users: {str(e)}")
            raise

    async def bulk_create(self, entities: List[User]) -> List[User]:
        """Bulk create users"""
        try:
            return await self._user_repository.bulk_create_users([e.__dict__ for e in entities])
        except Exception as e:
            logger.error(f"Error bulk creating users: {str(e)}")
            raise

    async def exists(self, **filters: Any) -> bool:
        """Check if user exists with given filters"""
        try:
            return await self._user_repository.user_exists(**filters)
        except Exception as e:
            logger.error(f"Error checking user existence: {str(e)}")
            raise

    async def filter(self, *conditions: Any, skip: int = 0, limit: int = 100) -> List[User]:
        """Filter users with conditions"""
        try:
            return await self._user_repository.filter_users(*conditions, skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error filtering users: {str(e)}")
            raise

    async def get_paginated(self, page: int, per_page: int) -> List[User]:
        """Get paginated list of users"""
        try:
            return await self._user_repository.get_users_paginated(page, per_page)
        except Exception as e:
            logger.error(f"Error getting paginated users: {str(e)}")
            raise

    async def get_sorted(self, sort_field: str, ascending: bool = True, *, skip: int = 0, limit: int = 100) -> List[User]:
        """Get sorted list of users"""
        try:
            return await self._user_repository.get_sorted_users(sort_field, ascending, skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting sorted users: {str(e)}")
            raise
