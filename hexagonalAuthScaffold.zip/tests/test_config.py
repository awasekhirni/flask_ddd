# #Copyright (C) 2025 β ORI Inc.
# #Written by Awase Khirni Syed 2025
# tests/test_config.py
import os
from unittest.mock import patch

import pytest
from pydantic import ValidationError

from config import Settings, get_settings


class TestConfig:
    """Test configuration settings"""

    # Test default values
    def test_default_values(self):
        settings = Settings()
        assert settings.APP_DEBUG is False
        assert settings.APP_FLASK_ENV == "production"
        assert settings.APP_APP_NAME == "Hexagonal Auth API"
        assert settings.APP_APP_VERSION == "1.0.0"
        assert settings.APP_POSTGRES_HOST == "localhost"
        assert settings.APP_POSTGRES_PORT == "5432"
        assert settings.APP_DB_POOL_SIZE == 5
        assert settings.APP_DB_MAX_OVERFLOW == 10
        assert settings.APP_DB_POOL_RECYCLE == 3600
        assert settings.APP_ALGORITHM == "HS256"
        assert settings.APP_ACCESS_TOKEN_EXPIRE_MINUTES == 30
        assert settings.APP_LOG_LEVEL == "INFO"
        assert settings.APP_LOG_DIR == "logs"
        assert settings.APP_LOG_MAX_BYTES == 5_000_000
        assert settings.APP_LOG_BACKUP_COUNT == 3
        assert settings.APP_LOG_ENABLE_CONSOLE is True
        assert settings.APP_LOG_ENABLE_FILE is False

    # Test required fields without defaults
    def test_required_fields_missing(self):
        with pytest.raises(ValidationError):
            Settings(
                APP_POSTGRES_USER=None,
                APP_POSTGRES_PASSWORD=None,
                APP_POSTGRES_DB=None,
                APP_SECRET_KEY=None,
            )

    # Test database URL construction
    def test_database_url_property(self):
        settings = Settings(
            APP_POSTGRES_USER="testuser",
            APP_POSTGRES_PASSWORD="testpass",
            APP_POSTGRES_DB="testdb",
            APP_POSTGRES_HOST="dbhost",
            APP_POSTGRES_PORT="5433",
        )
        assert settings.database_url == "postgresql+asyncpg://testuser:testpass@dbhost:5433/testdb"

    # Test secret values are properly masked
    def test_secret_values_masked(self):
        settings = Settings(
            APP_POSTGRES_USER="user",
            APP_POSTGRES_PASSWORD="secret",
            APP_POSTGRES_DB="db",
            APP_SECRET_KEY="supersecret",
        )
        assert "secret" not in repr(settings.APP_POSTGRES_PASSWORD)
        assert "supersecret" not in repr(settings.APP_SECRET_KEY)

    # Test environment variable loading
    @patch.dict(
        os.environ,
        {
            "APP_POSTGRES_USER": "envuser",
            "APP_POSTGRES_PASSWORD": "envpass",
            "APP_POSTGRES_DB": "envdb",
            "APP_SECRET_KEY": "envsecret",
            "APP_LOG_LEVEL": "DEBUG",
        },
    )
    def test_env_variable_loading(self):
        settings = Settings()
        assert settings.APP_POSTGRES_USER == "envuser"
        assert settings.APP_POSTGRES_PASSWORD.get_secret_value() == "envpass"
        assert settings.APP_POSTGRES_DB == "envdb"
        assert settings.APP_SECRET_KEY.get_secret_value() == "envsecret"
        assert settings.APP_LOG_LEVEL == "DEBUG"

    # Test settings caching
    def test_settings_caching(self):
        settings1 = get_settings()
        settings2 = get_settings()
        assert settings1 is settings2  # Same object due to caching

    # Test invalid values
    @pytest.mark.parametrize(
        "invalid_value,field",
        [
            (123, "APP_DEBUG"),  # Should be bool
            ("invalid", "APP_FLASK_ENV"),  # Not in allowed values
            (-1, "APP_DB_POOL_SIZE"),  # Negative number
            ("notanumber", "APP_LOG_MAX_BYTES"),  # Not an integer
        ],
    )
    def test_invalid_values(self, invalid_value, field):
        with pytest.raises(ValidationError):
            Settings(
                APP_POSTGRES_USER="user",
                APP_POSTGRES_PASSWORD="pass",
                APP_POSTGRES_DB="db",
                APP_SECRET_KEY="secret",
                **{field: invalid_value},
            )
